<?php $__env->startSection('title', 'Kelola Kategori Sampah - Admin'); ?>
<?php $__env->startSection('header'); ?>
    <div class="d-flex justify-content-between align-items-center">
        <h1 class="h3 mb-0">Kelola Kategori Sampah</h1>
        <a href="<?php echo e(route('admin.kategori.create')); ?>" class="btn btn-netra">
            <i class="fas fa-plus me-1"></i> Tambah Item Spesifik
        </a>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- KATEGORI UTAMA (LOCKED) -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-lock me-2"></i> Kategori Utama</h5>
                <span class="badge bg-light text-dark"><?php echo e($kategorisUtama->count()); ?> kategori</span>
            </div>
        </div>
        <div class="card-body">
            <?php if($kategorisUtama->isEmpty()): ?>
                <div class="text-center py-3">
                    <p class="text-muted">Belum ada kategori utama</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nama Kategori</th>
                                <th>Jenis</th>
                                <th>Poin per Kg</th>
                                <th>Status Sistem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kategorisUtama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="rounded-circle me-2" 
                                                 style="width: 16px; height: 16px; background-color: <?php echo e($kategori->warna_label ?? '#3b82f6'); ?>"></div>
                                            <strong><?php echo e($kategori->nama_kategori); ?></strong>
                                            <i class="fas fa-lock text-muted ms-2" title="Kategori Terkunci"></i>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($kategori->jenis_badge); ?>">
                                            <?php echo e($kategori->jenis_label); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($kategori->poin_formatted); ?></td>
                                    <td>
                                        <span class="badge bg-danger">
                                            <i class="fas fa-ban me-1"></i> Terkunci
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ITEM SPESIFIK (UNLOCKED) -->
    <div class="card">
        <div class="card-header bg-success text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-tags me-2"></i> Item Spesifik</h5>
                <span class="badge bg-light text-dark"><?php echo e($kategorisBiasa->count()); ?> item</span>
            </div>
        </div>
        <div class="card-body">
            <?php if($kategorisBiasa->isEmpty()): ?>
                <div class="text-center py-5">
                    <i class="fas fa-box-open fa-3x text-muted mb-3"></i>
                    <h5>Belum ada item spesifik</h5>
                    <p class="text-muted">Tambahkan item spesifik seperti botol plastik, besi, dll.</p>
                    <a href="<?php echo e(route('admin.kategori.create')); ?>" class="btn btn-netra">
                        <i class="fas fa-plus me-1"></i> Tambah Item Spesifik
                    </a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nama Item</th>
                                <th>Kategori Utama</th>
                                <th>Poin per Kg</th>
                                <th class="text-end">Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kategorisBiasa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="rounded-circle me-2" 
                                                 style="width: 16px; height: 16px; background-color: <?php echo e($kategori->warna_label ?? '#3b82f6'); ?>"></div>
                                            <?php echo e($kategori->nama_kategori); ?>

                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($kategori->jenis_badge); ?>">
                                            <?php echo e($kategori->jenis_label); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($kategori->poin_formatted); ?></td>
                                    <td>
                                        <div class="d-flex justify-content-end gap-2">
                                            <a href="<?php echo e(route('admin.kategori.edit', $kategori->id)); ?>" 
                                               class="btn btn-sm btn-outline-primary"
                                               title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            
                                            <button type="button" 
                                                    class="btn btn-sm btn-outline-danger delete-item"
                                                    data-id="<?php echo e($kategori->id); ?>"
                                                    data-name="<?php echo e($kategori->nama_kategori); ?>"
                                                    data-used="<?php echo e($kategori->isUsedInTransactions ? 'true' : 'false'); ?>"
                                                    title="Hapus">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Delete Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p id="deleteMessage">Apakah Anda yakin ingin menghapus item ini?</p>
                    <div id="usedWarning" class="alert alert-warning d-none">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Item ini telah digunakan dalam transaksi. 
                        <strong>Hapus tidak diperbolehkan.</strong> 
                        Anda dapat menonaktifkan item ini agar tidak muncul di transaksi baru.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <form id="deleteForm" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="hidden" name="force_delete" id="forceDelete" value="0">
                    </form>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Hapus</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        let deleteUrl = '';
        let itemName = '';
        let isUsed = false;
        
        // Event listener untuk tombol delete
        document.querySelectorAll('.delete-item').forEach(button => {
            button.addEventListener('click', function() {
                const itemId = this.getAttribute('data-id');
                itemName = this.getAttribute('data-name');
                isUsed = this.getAttribute('data-used') === 'true';
                
                deleteUrl = `/admin/kategori/${itemId}`;
                
                // Update modal content
                if (isUsed) {
                    document.getElementById('deleteMessage').textContent = `Item "${itemName}"`;
                    document.getElementById('usedWarning').classList.remove('d-none');
                    document.getElementById('confirmDeleteBtn').classList.add('d-none');
                } else {
                    document.getElementById('deleteMessage').innerHTML = 
                        `Apakah Anda yakin ingin menghapus <strong>${itemName}</strong>?<br>
                         <small class="text-danger">Data yang sudah dihapus tidak dapat dikembalikan.</small>`;
                    document.getElementById('usedWarning').classList.add('d-none');
                    document.getElementById('confirmDeleteBtn').classList.remove('d-none');
                }
                
                // Show modal
                const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
                deleteModal.show();
            });
        });
        
        // Konfirmasi delete
        document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
            const form = document.getElementById('deleteForm');
            form.action = deleteUrl;
            form.submit();
        });
        
        // SweetAlert untuk success/error messages dari session
        <?php if(session('success')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: '<?php echo e(session("success")); ?>',
                timer: 3000,
                showConfirmButton: false
            });
        <?php endif; ?>
        
        <?php if(session('error')): ?>
            Swal.fire({
                icon: 'error',
                title: 'Gagal!',
                text: '<?php echo e(session("error")); ?>',
                timer: 4000,
                showConfirmButton: true
            });
        <?php endif; ?>
        
        <?php if(session('warning')): ?>
            Swal.fire({
                icon: 'warning',
                title: 'Peringatan!',
                text: '<?php echo e(session("warning")); ?>',
                timer: 4000,
                showConfirmButton: true
            });
        <?php endif; ?>
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\netrash_update\netrash\resources\views/admin/kategori/index.blade.php ENDPATH**/ ?>