<?php $__env->startSection('title', 'Dashboard Reports'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h2 class="mb-0">
                    <i class="fas fa-chart-line me-2"></i> Dashboard Reports
                </h2>
                <p class="text-muted mb-0">Analisis dan statistik sistem NetraTrash</p>
            </div>
            <div>
                <button class="btn btn-netra" onclick="window.print()">
                    <i class="fas fa-print me-2"></i> Print Dashboard
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Report Selection Tabs -->
<div class="card mb-4">
    <div class="card-header bg-light p-0">
        <ul class="nav nav-tabs nav-fill" id="reportTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="sampah-tab" data-bs-toggle="tab" data-bs-target="#sampah" type="button" role="tab">
                    <i class="fas fa-trash me-2"></i> Laporan Transaksi Sampah
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="penukaran-tab" data-bs-toggle="tab" data-bs-target="#penukaran" type="button" role="tab">
                    <i class="fas fa-exchange-alt me-2"></i> Laporan Penukaran Barang
                </button>
            </li>
        </ul>
    </div>
</div>

<!-- Transaksi Sampah Tab -->
<div class="tab-content" id="reportTabsContent">
    <!-- Tab 1: Transaksi Sampah -->
    <div class="tab-pane fade show active" id="sampah" role="tabpanel">
        <!-- Filter Card for Sampah -->
        <div class="card mb-4">
            <div class="card-header bg-light">
                <h5 class="mb-0">
                    <i class="fas fa-filter me-2"></i> Filter Laporan Transaksi Sampah
                </h5>
            </div>
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('admin.reports.index')); ?>" class="row g-3">
                    <input type="hidden" name="tab" value="sampah">
                    <div class="col-md-3">
                        <label class="form-label">Tanggal Mulai</label>
                        <input type="date" name="start_date" class="form-control" 
                               value="<?php echo e(request('start_date', date('Y-m-01'))); ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Tanggal Selesai</label>
                        <input type="date" name="end_date" class="form-control" 
                               value="<?php echo e(request('end_date', date('Y-m-d'))); ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="">Semua Status</option>
                            <option value="completed" <?php echo e(request('status') == 'completed' ? 'selected' : ''); ?>>Selesai</option>
                            <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="cancelled" <?php echo e(request('status') == 'cancelled' ? 'selected' : ''); ?>>Dibatalkan</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Petugas</label>
                        <select name="petugas_id" class="form-select">
                            <option value="">Semua Petugas</option>
                            <?php $__currentLoopData = $petugasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $petugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($petugas->id); ?>" <?php echo e(request('petugas_id') == $petugas->id ? 'selected' : ''); ?>>
                                <?php echo e($petugas->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-netra">
                            <i class="fas fa-filter me-2"></i> Filter Data Sampah
                        </button>
                        <a href="<?php echo e(route('admin.reports.index')); ?>?tab=sampah" class="btn btn-outline-secondary">
                            <i class="fas fa-redo me-2"></i> Reset Filter
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Summary Statistics for Sampah -->
        <?php if(isset($sampahSummary)): ?>
        <div class="row mb-4">
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-start border-success border-4 h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Total Transaksi Sampah</h6>
                                <h3 class="mb-0"><?php echo e(number_format($sampahSummary['total_transaksi'] ?? 0)); ?></h3>
                                <small class="text-muted">
                                    <i class="fas fa-calendar-alt me-1"></i> 
                                    <?php echo e(\Carbon\Carbon::parse(request('start_date', date('Y-m-01')))->format('d/m/Y')); ?> 
                                    - <?php echo e(\Carbon\Carbon::parse(request('end_date', date('Y-m-d')))->format('d/m/Y')); ?>

                                </small>
                            </div>
                            <div class="bg-success bg-opacity-10 p-3 rounded-circle">
                                <i class="fas fa-trash fa-2x text-success"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-start border-info border-4 h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Total Berat Sampah</h6>
                                <h3 class="mb-0"><?php echo e(number_format($sampahSummary['total_berat'] ?? 0, 1)); ?> kg</h3>
                                <small class="text-muted">
                                    <i class="fas fa-weight-hanging me-1"></i> Berat terkumpul
                                </small>
                            </div>
                            <div class="bg-info bg-opacity-10 p-3 rounded-circle">
                                <i class="fas fa-weight fa-2x text-info"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-start border-warning border-4 h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Total Poin Diberikan</h6>
                                <h3 class="mb-0"><?php echo e(number_format($sampahSummary['total_poin'] ?? 0)); ?></h3>
                                <small class="text-muted">
                                    <i class="fas fa-coins me-1"></i> Poin diberikan
                                </small>
                            </div>
                            <div class="bg-warning bg-opacity-10 p-3 rounded-circle">
                                <i class="fas fa-coins fa-2x text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-start border-primary border-4 h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Warga Aktif</h6>
                                <h3 class="mb-0"><?php echo e(number_format($sampahSummary['total_warga'] ?? 0)); ?></h3>
                                <small class="text-muted">
                                    <i class="fas fa-users me-1"></i> Partisipan transaksi
                                </small>
                            </div>
                            <div class="bg-primary bg-opacity-10 p-3 rounded-circle">
                                <i class="fas fa-user-check fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Transactions Table for Sampah -->
        <div class="card">
            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-trash me-2"></i> Daftar Transaksi Sampah
                </h5>
                <div>
                    <button type="button" class="btn btn-sm btn-netra" data-bs-toggle="modal" data-bs-target="#exportSampahModal">
                        <i class="fas fa-download me-1"></i> Export Transaksi Sampah
                    </button>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover table-sm mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 5%;">ID</th>
                                <th style="width: 15%;">Tanggal</th>
                                <th style="width: 25%;">Warga</th>
                                <th style="width: 20%;">Petugas</th>
                                <th style="width: 10%;" class="text-end">Berat (kg)</th>
                                <th style="width: 10%;" class="text-end">Poin</th>
                                <th style="width: 10%;">Status</th>
                                <th style="width: 5%;" class="text-center">Detail</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $sampahTransaksi ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <span class="badge bg-secondary">#<?php echo e($item->id); ?></span>
                                </td>
                                <td>
                                    <small class="text-muted d-block"><?php echo e($item->created_at->format('d/m/Y')); ?></small>
                                    <small class="text-muted"><?php echo e($item->created_at->format('H:i')); ?></small>
                                </td>
                                <td>
                                    <div class="fw-semibold"><?php echo e($item->warga->name ?? 'N/A'); ?></div>
                                    <?php if($item->warga->phone ?? false): ?>
                                    <small class="text-muted"><?php echo e($item->warga->phone); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->petugas->name ?? 'N/A'); ?></td>
                                <td class="text-end fw-semibold"><?php echo e(number_format($item->total_berat, 2)); ?></td>
                                <td class="text-end">
                                    <span class="badge bg-success rounded-pill px-2">
                                        <?php echo e(number_format($item->total_poin)); ?>

                                    </span>
                                </td>
                                <td>
                                    <?php
                                        $statusColors = [
                                            'completed' => 'success',
                                            'pending' => 'warning',
                                            'cancelled' => 'danger'
                                        ];
                                        $statusIcons = [
                                            'completed' => 'check-circle',
                                            'pending' => 'clock',
                                            'cancelled' => 'times-circle'
                                        ];
                                    ?>
                                    <span class="badge bg-<?php echo e($statusColors[$item->status] ?? 'secondary'); ?>">
                                        <i class="fas fa-<?php echo e($statusIcons[$item->status] ?? 'circle'); ?> me-1"></i>
                                        <?php echo e(ucfirst($item->status)); ?>

                                    </span>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('admin.transaksi.show', $item->id)); ?>" 
                                       class="btn btn-sm btn-outline-netra" 
                                       title="Detail" data-bs-toggle="tooltip">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4">
                                    <i class="fas fa-inbox fa-2x text-muted mb-2"></i>
                                    <p class="text-muted mb-0">Tidak ada data transaksi sampah pada periode ini</p>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                        <?php if(($sampahTransaksi ?? collect())->count() > 0): ?>
                        <tfoot class="table-light">
                            <tr>
                                <td colspan="4" class="text-end fw-bold">Total:</td>
                                <td class="text-end fw-bold"><?php echo e(number_format($sampahSummary['total_berat'] ?? 0, 2)); ?> kg</td>
                                <td class="text-end fw-bold"><?php echo e(number_format($sampahSummary['total_poin'] ?? 0)); ?></td>
                                <td colspan="2"></td>
                            </tr>
                        </tfoot>
                        <?php endif; ?>
                    </table>
                </div>
                
                <?php if(($sampahTransaksi ?? collect())->count() > 0): ?>
                <div class="card-footer">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-0">
                                Menampilkan <?php echo e(($sampahTransaksi ?? collect())->count()); ?> dari <?php echo e($sampahSummary['total_transaksi'] ?? 0); ?> transaksi sampah
                            </p>
                        </div>
                        <div>
                            <small class="text-muted">
                                Periode: <?php echo e(\Carbon\Carbon::parse(request('start_date', date('Y-m-01')))->format('d/m/Y')); ?> 
                                - <?php echo e(\Carbon\Carbon::parse(request('end_date', date('Y-m-d')))->format('d/m/Y')); ?>

                            </small>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($sampahTransaksi->links()); ?>

                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Tab 2: Penukaran Barang -->
    <div class="tab-pane fade" id="penukaran" role="tabpanel">
        <!-- Filter Card for Penukaran -->
        <div class="card mb-4">
            <div class="card-header bg-light">
                <h5 class="mb-0">
                    <i class="fas fa-filter me-2"></i> Filter Laporan Penukaran Barang
                </h5>
            </div>
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('admin.reports.index')); ?>" class="row g-3">
                    <input type="hidden" name="tab" value="penukaran">
                    <div class="col-md-3">
                        <label class="form-label">Tanggal Mulai</label>
                        <input type="date" name="start_date_penukaran" class="form-control" 
                               value="<?php echo e(request('start_date_penukaran', date('Y-m-01'))); ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Tanggal Selesai</label>
                        <input type="date" name="end_date_penukaran" class="form-control" 
                               value="<?php echo e(request('end_date_penukaran', date('Y-m-d'))); ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Status Penukaran</label>
                        <select name="status_penukaran" class="form-select">
                            <option value="">Semua Status</option>
                            <option value="pending" <?php echo e(request('status_penukaran') == 'pending' ? 'selected' : ''); ?>>Menunggu Acc</option>
                            <option value="completed" <?php echo e(request('status_penukaran') == 'completed' ? 'selected' : ''); ?>>Disetujui</option>
                            <option value="cancelled" <?php echo e(request('status_penukaran') == 'cancelled' ? 'selected' : ''); ?>>Ditolak</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Admin</label>
                        <select name="admin_id" class="form-select">
                            <option value="">Semua Admin</option>
                            <?php $__currentLoopData = $adminList ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($admin->id); ?>" <?php echo e(request('admin_id') == $admin->id ? 'selected' : ''); ?>>
                                <?php echo e($admin->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-netra">
                            <i class="fas fa-filter me-2"></i> Filter Data Penukaran
                        </button>
                        <a href="<?php echo e(route('admin.reports.index')); ?>?tab=penukaran" class="btn btn-outline-secondary">
                            <i class="fas fa-redo me-2"></i> Reset Filter
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Summary Statistics for Penukaran -->
        <?php if(isset($penukaranSummary)): ?>
        <div class="row mb-4">
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-start border-info border-4 h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Total Penukaran</h6>
                                <h3 class="mb-0"><?php echo e(number_format($penukaranSummary['total_transaksi'] ?? 0)); ?></h3>
                                <small class="text-muted">
                                    <i class="fas fa-calendar-alt me-1"></i> 
                                    <?php echo e(\Carbon\Carbon::parse(request('start_date_penukaran', date('Y-m-01')))->format('d/m/Y')); ?> 
                                    - <?php echo e(\Carbon\Carbon::parse(request('end_date_penukaran', date('Y-m-d')))->format('d/m/Y')); ?>

                                </small>
                            </div>
                            <div class="bg-info bg-opacity-10 p-3 rounded-circle">
                                <i class="fas fa-exchange-alt fa-2x text-info"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-start border-danger border-4 h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Total Poin Ditukar</h6>
                                <h3 class="mb-0"><?php echo e(number_format($penukaranSummary['total_poin'] ?? 0)); ?></h3>
                                <small class="text-muted">
                                    <i class="fas fa-coins me-1"></i> Poin berkurang
                                </small>
                            </div>
                            <div class="bg-danger bg-opacity-10 p-3 rounded-circle">
                                <i class="fas fa-minus-circle fa-2x text-danger"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-start border-success border-4 h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Penukaran Disetujui</h6>
                                <h3 class="mb-0"><?php echo e(number_format($penukaranSummary['completed'] ?? 0)); ?></h3>
                                <small class="text-muted">
                                    <i class="fas fa-check-circle me-1"></i> Berhasil ditukar
                                </small>
                            </div>
                            <div class="bg-success bg-opacity-10 p-3 rounded-circle">
                                <i class="fas fa-check fa-2x text-success"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-start border-warning border-4 h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Menunggu Acc</h6>
                                <h3 class="mb-0"><?php echo e(number_format($penukaranSummary['pending'] ?? 0)); ?></h3>
                                <small class="text-muted">
                                    <i class="fas fa-clock me-1"></i> Menunggu persetujuan
                                </small>
                            </div>
                            <div class="bg-warning bg-opacity-10 p-3 rounded-circle">
                                <i class="fas fa-hourglass-half fa-2x text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Transactions Table for Penukaran -->
        <div class="card">
            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-exchange-alt me-2"></i> Daftar Penukaran Barang
                </h5>
                <div>
                    <button type="button" class="btn btn-sm btn-netra" data-bs-toggle="modal" data-bs-target="#exportPenukaranModal">
                        <i class="fas fa-download me-1"></i> Export Penukaran Barang
                    </button>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover table-sm mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 5%;">ID</th>
                                <th style="width: 15%;">Tanggal</th>
                                <th style="width: 25%;">Warga</th>
                                <th style="width: 20%;">Admin</th>
                                <th style="width: 20%;">Barang</th>
                                <th style="width: 10%;" class="text-end">Poin</th>
                                <th style="width: 10%;">Status</th>
                                <th style="width: 5%;" class="text-center">Detail</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $penukaranTransaksi ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <span class="badge bg-secondary">#<?php echo e($item->id); ?></span>
                                </td>
                                <td>
                                    <small class="text-muted d-block"><?php echo e($item->created_at->format('d/m/Y')); ?></small>
                                    <small class="text-muted"><?php echo e($item->created_at->format('H:i')); ?></small>
                                </td>
                                <td>
                                    <div class="fw-semibold"><?php echo e($item->warga->name ?? 'N/A'); ?></div>
                                    <?php if($item->warga->phone ?? false): ?>
                                    <small class="text-muted"><?php echo e($item->warga->phone); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->admin->name ?? 'Belum diproses'); ?></td>
                                <td>
                                    <?php
                                        $barangInfo = $item->catatan ?? 'Penukaran Barang';
                                        // Extract barang info dari catatan
                                        if (preg_match('/Penukaran:\s*(.+?)\s*x(\d+)/', $barangInfo, $matches)) {
                                            $barangInfo = trim($matches[1]) . ' x' . $matches[2];
                                        }
                                    ?>
                                    <small><?php echo e(Str::limit($barangInfo, 30)); ?></small>
                                </td>
                                <td class="text-end">
                                    <span class="badge bg-danger rounded-pill px-2">
                                        <i class="fas fa-minus me-1"></i><?php echo e(number_format(abs($item->total_poin))); ?>

                                    </span>
                                </td>
                                <td>
                                    <?php
                                        $statusColors = [
                                            'pending' => 'warning',
                                            'completed' => 'success',
                                            'cancelled' => 'danger'
                                        ];
                                        $statusLabels = [
                                            'pending' => 'Menunggu Acc',
                                            'completed' => 'Disetujui',
                                            'cancelled' => 'Ditolak'
                                        ];
                                        $statusIcons = [
                                            'pending' => 'clock',
                                            'completed' => 'check-circle',
                                            'cancelled' => 'times-circle'
                                        ];
                                    ?>
                                    <span class="badge bg-<?php echo e($statusColors[$item->status_penukaran] ?? 'secondary'); ?>">
                                        <i class="fas fa-<?php echo e($statusIcons[$item->status_penukaran] ?? 'circle'); ?> me-1"></i>
                                        <?php echo e($statusLabels[$item->status_penukaran] ?? 'N/A'); ?>

                                    </span>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('admin.transaksi.show', $item->id)); ?>" 
                                       class="btn btn-sm btn-outline-netra" 
                                       title="Detail" data-bs-toggle="tooltip">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4">
                                    <i class="fas fa-inbox fa-2x text-muted mb-2"></i>
                                    <p class="text-muted mb-0">Tidak ada data penukaran barang pada periode ini</p>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                        <?php if(($penukaranTransaksi ?? collect())->count() > 0): ?>
                        <tfoot class="table-light">
                            <tr>
                                <td colspan="5" class="text-end fw-bold">Total Poin Ditukar:</td>
                                <td class="text-end fw-bold"><?php echo e(number_format($penukaranSummary['total_poin'] ?? 0)); ?></td>
                                <td colspan="2"></td>
                            </tr>
                        </tfoot>
                        <?php endif; ?>
                    </table>
                </div>
                
                <?php if(($penukaranTransaksi ?? collect())->count() > 0): ?>
                <div class="card-footer">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-0">
                                Menampilkan <?php echo e(($penukaranTransaksi ?? collect())->count()); ?> dari <?php echo e($penukaranSummary['total_transaksi'] ?? 0); ?> penukaran barang
                            </p>
                        </div>
                        <div>
                            <small class="text-muted">
                                Periode: <?php echo e(\Carbon\Carbon::parse(request('start_date_penukaran', date('Y-m-01')))->format('d/m/Y')); ?> 
                                - <?php echo e(\Carbon\Carbon::parse(request('end_date_penukaran', date('Y-m-d')))->format('d/m/Y')); ?>

                            </small>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($penukaranTransaksi->links()); ?>

                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Export Modal for Sampah -->
<div class="modal fade" id="exportSampahModal" tabindex="-1" aria-labelledby="exportSampahModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exportSampahModalLabel">
                    <i class="fas fa-download me-2"></i> Export Transaksi Sampah
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="exportSampahForm" action="<?php echo e(route('admin.reports.export')); ?>" method="POST" target="_blank">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="report" value="dashboard">
                    <input type="hidden" name="type_report" value="sampah">
                    <input type="hidden" name="start_date" value="<?php echo e(request('start_date', date('Y-m-01'))); ?>">
                    <input type="hidden" name="end_date" value="<?php echo e(request('end_date', date('Y-m-d'))); ?>">
                    <input type="hidden" name="status" value="<?php echo e(request('status')); ?>">
                    <input type="hidden" name="petugas_id" value="<?php echo e(request('petugas_id')); ?>">
                    
                    <div class="mb-3">
                        <label class="form-label">Format Export</label>
                        <div class="d-flex gap-3">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="type" id="excelSampah" value="excel" checked>
                                <label class="form-check-label d-flex align-items-center" for="excelSampah">
                                    <i class="fas fa-file-excel text-success me-2 fs-5"></i>
                                    <div>
                                        <div class="fw-bold">Excel</div>
                                        <small class="text-muted">.xlsx</small>
                                    </div>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="type" id="pdfSampah" value="pdf">
                                <label class="form-check-label d-flex align-items-center" for="pdfSampah">
                                    <i class="fas fa-file-pdf text-danger me-2 fs-5"></i>
                                    <div>
                                        <div class="fw-bold">PDF</div>
                                        <small class="text-muted">.pdf</small>
                                    </div>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="fileNameSampah" class="form-label">Nama File</label>
                        <input type="text" class="form-control" id="fileNameSampah" 
                               name="file_name" 
                               value="Transaksi_Sampah_<?php echo e(date('Y-m-d')); ?>" 
                               placeholder="Masukkan nama file"
                               required>
                        <small class="text-muted">File akan didownload dengan ekstensi sesuai format</small>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" form="exportSampahForm" class="btn btn-netra">
                    <i class="fas fa-download me-2"></i> Download
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Export Modal for Penukaran -->
<div class="modal fade" id="exportPenukaranModal" tabindex="-1" aria-labelledby="exportPenukaranModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exportPenukaranModalLabel">
                    <i class="fas fa-download me-2"></i> Export Penukaran Barang
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="exportPenukaranForm" action="<?php echo e(route('admin.reports.export')); ?>" method="POST" target="_blank">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="report" value="dashboard">
                    <input type="hidden" name="type_report" value="penukaran">
                    <input type="hidden" name="start_date" value="<?php echo e(request('start_date_penukaran', date('Y-m-01'))); ?>">
                    <input type="hidden" name="end_date" value="<?php echo e(request('end_date_penukaran', date('Y-m-d'))); ?>">
                    <input type="hidden" name="status_penukaran" value="<?php echo e(request('status_penukaran')); ?>">
                    <input type="hidden" name="admin_id" value="<?php echo e(request('admin_id')); ?>">
                    
                    <div class="mb-3">
                        <label class="form-label">Format Export</label>
                        <div class="d-flex gap-3">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="type" id="excelPenukaran" value="excel" checked>
                                <label class="form-check-label d-flex align-items-center" for="excelPenukaran">
                                    <i class="fas fa-file-excel text-success me-2 fs-5"></i>
                                    <div>
                                        <div class="fw-bold">Excel</div>
                                        <small class="text-muted">.xlsx</small>
                                    </div>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="type" id="pdfPenukaran" value="pdf">
                                <label class="form-check-label d-flex align-items-center" for="pdfPenukaran">
                                    <i class="fas fa-file-pdf text-danger me-2 fs-5"></i>
                                    <div>
                                        <div class="fw-bold">PDF</div>
                                        <small class="text-muted">.pdf</small>
                                    </div>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="fileNamePenukaran" class="form-label">Nama File</label>
                        <input type="text" class="form-control" id="fileNamePenukaran" 
                               name="file_name" 
                               value="Penukaran_Barang_<?php echo e(date('Y-m-d')); ?>" 
                               placeholder="Masukkan nama file"
                               required>
                        <small class="text-muted">File akan didownload dengan ekstensi sesuai format</small>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" form="exportPenukaranForm" class="btn btn-netra">
                    <i class="fas fa-download me-2"></i> Download
                </button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
      .nav-tabs .nav-link {
        border-bottom: 3px solid transparent;
        transition: all 0.3s;
        cursor: pointer;
    }
    
    .nav-tabs .nav-link.active {
        border-bottom-color: var(--bs-primary);
        color: var(--bs-primary);
        font-weight: 600;
        background-color: rgba(var(--bs-primary-rgb), 0.05);
    }
    
    .nav-tabs .nav-link:hover:not(.active) {
        background-color: rgba(0, 0, 0, 0.03);
    }
    .card {
        border-radius: 0.5rem;
        box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        transition: transform 0.2s;
    }
    
    .card:hover {
        transform: translateY(-2px);
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
    }
    
    .border-4 {
        border-width: 4px !important;
    }
    
    .bg-opacity-10 {
        background-color: rgba(var(--bs-primary-rgb), 0.1);
    }
    
    .badge {
        font-size: 0.8em;
        font-weight: 500;
    }
    
    .table > :not(caption) > * > * {
        padding: 0.75rem 0.5rem;
    }
    
    .nav-tabs .nav-link {
        border-bottom: 3px solid transparent;
        transition: all 0.3s;
    }
    
    .nav-tabs .nav-link.active {
        border-bottom-color: var(--bs-primary);
        color: var(--bs-primary);
        font-weight: 600;
    }
    
    @media print {
        .no-print {
            display: none !important;
        }
        
        .card-header, .card-footer, .modal, .btn, .nav-tabs {
            display: none !important;
        }
        
        .card {
            border: 1px solid #dee2e6 !important;
            box-shadow: none !important;
        }
        
        h2 {
            color: #000 !important;
        }
        
        .tab-pane {
            display: block !important;
            opacity: 1 !important;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // File name formatting
    const fileNameInputs = ['fileNameSampah', 'fileNamePenukaran'];
    fileNameInputs.forEach(id => {
        const input = document.getElementById(id);
        if (input) {
            input.addEventListener('input', function() {
                this.value = this.value.replace(/[^a-zA-Z0-9-_ ]/g, '').replace(/\s+/g, '_');
            });
        }
    });
    
    // Tab handling - IMPROVED VERSION
    const urlParams = new URLSearchParams(window.location.search);
    const activeTab = urlParams.get('tab') || 'sampah';
    
    // Fungsi untuk mengaktifkan tab berdasarkan ID
    function activateTab(tabId) {
        const tabButton = document.querySelector(`button[data-bs-target="#${tabId}"]`);
        if (tabButton) {
            const tab = new bootstrap.Tab(tabButton);
            tab.show();
            
            // Update URL tanpa reload
            const newUrl = new URL(window.location.href);
            newUrl.searchParams.set('tab', tabId);
            history.replaceState({}, '', newUrl);
        }
    }
    
    // Set active tab saat page load
    if (activeTab === 'penukaran') {
        activateTab('penukaran');
    }
    
    // Handle tab click events
    const triggerTabList = document.querySelectorAll('#reportTabs button[data-bs-toggle="tab"]');
    triggerTabList.forEach(triggerEl => {
        triggerEl.addEventListener('click', function(event) {
            event.preventDefault();
            const target = this.getAttribute('data-bs-target');
            const tabId = target.replace('#', '');
            
            // Update URL dengan parameter tab
            const newUrl = new URL(window.location.href);
            newUrl.searchParams.set('tab', tabId);
            
            // Redirect ke URL yang sama dengan parameter tab
            // Ini akan memastikan controller mendapatkan parameter yang benar
            window.location.href = newUrl.toString();
        });
    });
    
    // Handle form submit untuk menjaga tab state
    document.querySelectorAll('form').forEach(form => {
        const tabInput = form.querySelector('input[name="tab"]');
        if (!tabInput) {
            // Add hidden input untuk tab jika belum ada
            const activeTabEl = document.querySelector('#reportTabs .nav-link.active');
            if (activeTabEl) {
                const tabId = activeTabEl.getAttribute('data-bs-target').replace('#', '');
                const hiddenInput = document.createElement('input');
                hiddenInput.type = 'hidden';
                hiddenInput.name = 'tab';
                hiddenInput.value = tabId;
                form.appendChild(hiddenInput);
            }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\netrash_update\netrash\resources\views/admin/reports/index.blade.php ENDPATH**/ ?>