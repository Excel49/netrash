

<?php $__env->startSection('title', 'Daftar Transaksi Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center">
            <h2 class="mb-0">Daftar Transaksi</h2>
            <div>
                <a href="<?php echo e(route('admin.reports.transaksi')); ?>" class="btn btn-netra-outline me-2">
                    <i class="bi bi-bar-chart me-2"></i>Laporan
                </a>
                <a href="<?php echo e(route('admin.transaksi.export')); ?>" class="btn btn-success">
                    <i class="bi bi-download me-2"></i>Export
                </a>
            </div>
        </div>
        <p class="text-muted">Kelola semua transaksi sampah dan penukaran barang</p>
    </div>
</div>

<!-- Stats Cards -->
<div class="row mb-4">
    <div class="col-md-3 col-sm-6 mb-3">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="text-uppercase mb-0">Total</h6>
                        <h3 class="mb-0"><?php echo e($transaksi->total()); ?></h3>
                    </div>
                    <div class="align-self-center">
                        <i class="bi bi-receipt fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 col-sm-6 mb-3">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="text-uppercase mb-0">Sampah</h6>
                        <h3 class="mb-0"><?php echo e($transaksi->where('jenis_transaksi', '!=', 'penukaran')->count()); ?></h3>
                    </div>
                    <div class="align-self-center">
                        <i class="bi bi-trash fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 col-sm-6 mb-3">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="text-uppercase mb-0">Penukaran</h6>
                        <h3 class="mb-0"><?php echo e($transaksi->where('jenis_transaksi', 'penukaran')->count()); ?></h3>
                    </div>
                    <div class="align-self-center">
                        <i class="bi bi-basket fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 col-sm-6 mb-3">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="text-uppercase mb-0">Pending</h6>
                        <h3 class="mb-0"><?php echo e($transaksi->where(function($q) {
                            return $q->where('status', 'pending')->orWhere('status_penukaran', 'pending');
                        })->count()); ?></h3>
                    </div>
                    <div class="align-self-center">
                        <i class="bi bi-clock fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filter dan Search -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.transaksi.index')); ?>" class="row g-3">
            <div class="col-md-3">
                <label for="search" class="form-label">Cari Transaksi</label>
                <input type="text" class="form-control" id="search" name="search" 
                       value="<?php echo e(request('search')); ?>" placeholder="Kode transaksi atau nama warga...">
            </div>
            
            <div class="col-md-2">
                <label for="jenis_transaksi" class="form-label">Jenis Transaksi</label>
                <select class="form-control" id="jenis_transaksi" name="jenis_transaksi">
                    <option value="">Semua Jenis</option>
                    <option value="setoran" <?php echo e(request('jenis_transaksi') == 'setoran' ? 'selected' : ''); ?>>Setoran Sampah</option>
                    <option value="penukaran" <?php echo e(request('jenis_transaksi') == 'penukaran' ? 'selected' : ''); ?>>Penukaran Barang</option>
                </select>
            </div>
            
            <div class="col-md-2">
                <label for="status" class="form-label">Status</label>
                <select class="form-control" id="status" name="status">
                    <option value="">Semua Status</option>
                    <option value="completed" <?php echo e(request('status') == 'completed' ? 'selected' : ''); ?>>Selesai/Disetujui</option>
                    <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending/Menunggu</option>
                    <option value="cancelled" <?php echo e(request('status') == 'cancelled' ? 'selected' : ''); ?>>Dibatalkan/Ditolak</option>
                </select>
            </div>
            
            <div class="col-md-2">
                <label for="date" class="form-label">Tanggal</label>
                <input type="date" class="form-control" id="date" name="date" 
                       value="<?php echo e(request('date')); ?>">
            </div>
            
            <div class="col-md-1 d-flex align-items-end">
                <div class="d-grid w-100">
                    <button type="submit" class="btn btn-netra">
                        <i class="bi bi-search me-2"></i>Filter
                    </button>
                </div>
            </div>
            
            <div class="col-md-1 d-flex align-items-end">
                <div class="d-grid w-100">
                    <a href="<?php echo e(route('admin.transaksi.index')); ?>" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-clockwise me-2"></i>Reset
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Table Transaksi -->
<div class="card">
    <div class="card-body">
        <?php if($transaksi->isEmpty()): ?>
            <div class="text-center py-5">
                <i class="bi bi-receipt text-muted" style="font-size: 4rem;"></i>
                <h4 class="mt-3">Belum ada transaksi</h4>
                <p class="text-muted">Transaksi akan muncul di sini</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Kode Transaksi</th>
                            <th>Jenis</th>
                            <th>Warga</th>
                            <th>Petugas/Admin</th>
                            <th>Berat (kg)</th>
                            <th>Total Poin</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="<?php echo e($item->jenis_transaksi == 'penukaran' ? 'table-info' : ''); ?>">
                            <td><?php echo e($loop->iteration + (($transaksi->currentPage() - 1) * $transaksi->perPage())); ?></td>
                            <td>
                                <strong><?php echo e($item->kode_transaksi); ?></strong>
                                <?php if($item->jenis_transaksi == 'penukaran'): ?>
                                <br><small class="text-muted">Penukaran Barang</small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($item->jenis_transaksi == 'penukaran'): ?>
                                <span class="badge bg-info">Penukaran</span>
                                <?php else: ?>
                                <span class="badge bg-success">Sampah</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($item->warga->name ?? 'N/A'); ?>

                                <br><small class="text-muted"><?php echo e($item->warga->email ?? ''); ?></small>
                            </td>
                            <td>
                                <?php if($item->jenis_transaksi == 'penukaran' && $item->admin): ?>
                                    <span class="badge bg-secondary">Admin: <?php echo e($item->admin->name ?? 'N/A'); ?></span>
                                <?php else: ?>
                                    <?php echo e($item->petugas->name ?? 'N/A'); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($item->jenis_transaksi == 'penukaran'): ?>
                                    <span class="badge bg-light text-dark">-</span>
                                <?php else: ?>
                                    <span class="badge bg-info"><?php echo e(number_format($item->total_berat, 1)); ?> kg</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($item->jenis_transaksi == 'penukaran'): ?>
                                    <span class="badge bg-danger">
                                        <i class="bi bi-dash"></i><?php echo e(number_format(abs($item->total_poin))); ?> poin
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-success">
                                        <i class="bi bi-plus"></i><?php echo e(number_format($item->total_poin)); ?> poin
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($item->tanggal_transaksi->format('d/m/Y')); ?>

                                <br><small class="text-muted"><?php echo e($item->tanggal_transaksi->format('H:i')); ?></small>
                            </td>
                            <td>
                                <?php if($item->jenis_transaksi == 'penukaran'): ?>
                                    <!-- Hanya tampilkan status penukaran untuk transaksi penukaran -->
                                    <?php if($item->status_penukaran == 'pending'): ?>
                                        <span class="badge bg-warning">Menunggu Acc</span>
                                    <?php elseif($item->status_penukaran == 'completed'): ?>
                                        <span class="badge bg-success">Disetujui</span>
                                    <?php elseif($item->status_penukaran == 'cancelled'): ?>
                                        <span class="badge bg-danger">Ditolak</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">N/A</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <!-- Untuk transaksi sampah, tampilkan status biasa -->
                                    <?php if($item->status == 'completed'): ?>
                                        <span class="badge bg-success">Selesai</span>
                                    <?php elseif($item->status == 'pending'): ?>
                                        <span class="badge bg-warning">Pending</span>
                                    <?php elseif($item->status == 'cancelled'): ?>
                                        <span class="badge bg-danger">Dibatalkan</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">N/A</span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm" role="group">
                                    <a href="<?php echo e(route('admin.transaksi.show', $item->id)); ?>" 
                                       class="btn btn-outline-primary" title="Detail">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    
                                    <!-- Aksi Khusus Penukaran Pending -->
                                    <?php if($item->jenis_transaksi == 'penukaran' && $item->status_penukaran == 'pending'): ?>
                                        <!-- Modal untuk Approve -->
                                        <button type="button" class="btn btn-outline-success" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#approveModal<?php echo e($item->id); ?>"
                                                title="Setujui">
                                            <i class="bi bi-check"></i>
                                        </button>
                                        
                                        <!-- Modal untuk Reject -->
                                        <button type="button" class="btn btn-outline-danger" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#rejectModal<?php echo e($item->id); ?>"
                                                title="Tolak">
                                            <i class="bi bi-x"></i>
                                        </button>
                                    <?php endif; ?>
                                    
                                    <!-- Aksi untuk Transaksi Sampah Pending -->
                                    <?php if($item->jenis_transaksi != 'penukaran' && $item->status == 'pending'): ?>
                                        <form action="<?php echo e(route('admin.transaksi.verify', $item->id)); ?>" 
                                              method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-outline-success" 
                                                    title="Verifikasi"
                                                    onclick="return confirm('Verifikasi transaksi ini?')">
                                                <i class="bi bi-check"></i>
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('admin.transaksi.cancel', $item->id)); ?>" 
                                              method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-outline-danger" 
                                                    title="Batalkan"
                                                    onclick="return confirm('Batalkan transaksi ini?')">
                                                <i class="bi bi-x"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Modals untuk Penukaran -->
                                <?php if($item->jenis_transaksi == 'penukaran' && $item->status_penukaran == 'pending'): ?>
                                    <!-- Approve Modal -->
                                    <div class="modal fade" id="approveModal<?php echo e($item->id); ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('admin.transaksi.approve', $item->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-header bg-success text-white">
                                                        <h5 class="modal-title">Setujui Penukaran</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>Setujui penukaran barang oleh <strong><?php echo e($item->warga->name ?? 'Warga'); ?></strong>?</p>
                                                        <p><strong>Barang:</strong> <?php echo e($item->catatan); ?></p>
                                                        <p><strong>Poin:</strong> <?php echo e(number_format(abs($item->total_poin))); ?> poin akan dikurangi</p>
                                                        
                                                        <div class="mb-3">
                                                            <label for="catatan_admin<?php echo e($item->id); ?>" class="form-label">Catatan (Opsional)</label>
                                                            <textarea class="form-control" id="catatan_admin<?php echo e($item->id); ?>" 
                                                                      name="catatan_admin" rows="2" 
                                                                      placeholder="Catatan untuk warga..."></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                        <button type="submit" class="btn btn-success">Setujui Penukaran</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Reject Modal -->
                                    <div class="modal fade" id="rejectModal<?php echo e($item->id); ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('admin.transaksi.reject', $item->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-header bg-danger text-white">
                                                        <h5 class="modal-title">Tolak Penukaran</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>Tolak penukaran barang oleh <strong><?php echo e($item->warga->name ?? 'Warga'); ?></strong>?</p>
                                                        <p><strong>Barang:</strong> <?php echo e($item->catatan); ?></p>
                                                        
                                                        <div class="mb-3">
                                                            <label for="alasan_batal<?php echo e($item->id); ?>" class="form-label">Alasan Penolakan *</label>
                                                            <textarea class="form-control" id="alasan_batal<?php echo e($item->id); ?>" 
                                                                      name="alasan_batal" rows="3" 
                                                                      placeholder="Berikan alasan penolakan..." required></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                        <button type="submit" class="btn btn-danger">Tolak Penukaran</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="d-flex justify-content-between align-items-center mt-3">
                <div>
                    Menampilkan <?php echo e($transaksi->firstItem()); ?> sampai <?php echo e($transaksi->lastItem()); ?> 
                    dari <?php echo e($transaksi->total()); ?> transaksi
                </div>
                <div>
                    <?php echo e($transaksi->links()); ?>

                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Highlight filter yang aktif
    const filters = ['search', 'jenis_transaksi', 'status', 'date'];
    filters.forEach(filter => {
        const element = document.getElementById(filter);
        if(element && element.value) {
            element.classList.add('border-warning');
        }
    });
    
    // Auto close modal setelah submit
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        modal.addEventListener('shown.bs.modal', function() {
            const form = this.querySelector('form');
            if(form) {
                form.addEventListener('submit', function() {
                    const modalInstance = bootstrap.Modal.getInstance(modal);
                    modalInstance.hide();
                });
            }
        });
    });
    
    // Konfirmasi aksi
    document.querySelectorAll('form').forEach(form => {
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn && !form.querySelector('textarea')) {
            submitBtn.addEventListener('click', function(e) {
                if (!confirm('Anda yakin ingin melanjutkan?')) {
                    e.preventDefault();
                }
            });
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\netrash_update\netrash\resources\views/admin/transaksi/index.blade.php ENDPATH**/ ?>