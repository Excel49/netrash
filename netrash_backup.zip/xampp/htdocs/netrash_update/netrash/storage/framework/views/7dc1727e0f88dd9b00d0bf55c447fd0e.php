<?php $__env->startSection('title', 'Riwayat Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center">
            <h2 class="mb-0">Riwayat Transaksi Sampah</h2>
            <div>
                <a href="<?php echo e(route('warga.dashboard')); ?>" class="btn btn-netra-outline">
                    <i class="bi bi-arrow-left me-2"></i>Kembali
                </a>
            </div>
        </div>
        <p class="text-muted">Daftar semua transaksi setoran sampah Anda</p>
    </div>
</div>

<!-- Stats -->
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h6 class="card-title">Total Transaksi</h6>
                <h3><?php echo e($transaksi->total()); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h6 class="card-title">Total Poin</h6>
                <h3><?php echo e(number_format(auth()->user()->total_points, 0, ',', '.')); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <h6 class="card-title">Total Berat</h6>
                <h3><?php echo e(number_format($transaksi->sum('total_berat'), 1)); ?> kg</h3>
            </div>
        </div>
    </div>
</div>

<!-- Filter -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Tanggal Mulai</label>
                <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Tanggal Akhir</label>
                <input type="date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Petugas</label>
                <select name="petugas_id" class="form-select">
                    <option value="">Semua Petugas</option>
                    <?php $__currentLoopData = $transaksi->pluck('petugas')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $petugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($petugas): ?>
                    <option value="<?php echo e($petugas->id); ?>" <?php echo e(request('petugas_id') == $petugas->id ? 'selected' : ''); ?>>
                        <?php echo e($petugas->name); ?>

                    </option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3 d-flex align-items-end">
                <button type="submit" class="btn btn-netra me-2">
                    <i class="bi bi-filter me-2"></i>Filter
                </button>
                <a href="<?php echo e(route('warga.transaksi.index')); ?>" class="btn btn-outline-secondary">
                    Reset
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Table -->
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Kode Transaksi</th>
                        <th>Petugas</th>
                        <th>Berat (kg)</th>
                        <th>Total Poin</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($trx->tanggal_transaksi->format('d/m/Y H:i')); ?></td>
                        <td><?php echo e($trx->kode_transaksi); ?></td>
                        <td><?php echo e($trx->petugas->name ?? 'Sistem'); ?></td>
                        <td><?php echo e(number_format($trx->total_berat, 1)); ?></td>
                        <td class="text-success fw-bold">+<?php echo e(number_format($trx->total_poin, 0, ',', '.')); ?></td>
                        <td>
                            <?php if($trx->status == 'completed'): ?>
                            <span class="badge bg-success">Selesai</span>
                            <?php elseif($trx->status == 'pending'): ?>
                            <span class="badge bg-warning">Pending</span>
                            <?php else: ?>
                            <span class="badge bg-danger">Dibatalkan</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <a href="<?php echo e(route('warga.transaksi.show', $trx->id)); ?>" 
                                   class="btn btn-outline-primary" title="Detail">
                                    <i class="bi bi-eye"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">
                            <i class="bi bi-receipt display-4 d-block mb-2"></i>
                            Belum ada transaksi
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Pagination -->
    <?php if($transaksi->hasPages()): ?>
    <div class="card-footer">
        <?php echo e($transaksi->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\netrash_update\netrash\resources\views/warga/transaksi/index.blade.php ENDPATH**/ ?>