

<?php $__env->startSection('title', 'Detail Penukaran Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-md-8">
            <div class="d-flex align-items-center">
                <div class="rounded-circle bg-danger p-3 me-3">
                    <i class="fas fa-exchange-alt fa-lg text-white"></i>
                </div>
                <div>
                    <h1 class="h3 mb-1">Detail Penukaran Barang</h1>
                    <p class="text-muted mb-0">Rincian penukaran poin dengan barang</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('warga.barang.index', ['tab' => 'riwayat'])); ?>" class="btn btn-outline-netra">
                <i class="fas fa-arrow-left me-2"></i> Kembali ke Riwayat
            </a>
        </div>
    </div>

    <!-- Info Transaksi -->
    <div class="row mb-4">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-light">
                    <h6 class="mb-0">
                        <i class="fas fa-info-circle me-2"></i> Informasi Penukaran
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="40%">Kode Transaksi</th>
                                    <td>
                                        <span class="badge bg-secondary"><?php echo e($transaksi->kode_transaksi); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Tanggal</th>
                                    <td><?php echo e($transaksi->created_at->format('d F Y H:i')); ?></td>
                                </tr>
                                <tr>
                                    <th>Status</th>
                                    <td>
                                        <?php if($transaksi->status == 'completed'): ?>
                                        <span class="badge bg-success">Selesai</span>
                                        <?php elseif($transaksi->status == 'pending'): ?>
                                        <span class="badge bg-warning">Pending</span>
                                        <?php else: ?>
                                        <span class="badge bg-danger">Dibatalkan</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="40%">Jenis</th>
                                    <td>
                                        <span class="badge bg-danger">
                                            <i class="fas fa-exchange-alt me-1"></i> Penukaran Barang
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Petugas</th>
                                    <td><?php echo e($transaksi->petugas->name ?? 'Sistem'); ?></td>
                                </tr>
                                <tr>
                                    <th>Catatan</th>
                                    <td><?php echo e($transaksi->catatan); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Poin Card -->
        <div class="col-md-4">
            <div class="card border-danger">
                <div class="card-header bg-danger text-white">
                    <h6 class="mb-0">
                        <i class="fas fa-coins me-2"></i> Rincian Poin
                    </h6>
                </div>
                <div class="card-body">
                    <div class="text-center mb-4">
                        <div class="display-4 text-danger mb-2">
                            <i class="fas fa-arrow-down"></i>
                        </div>
                        <h2 class="text-danger"><?php echo e(number_format(abs($transaksi->total_poin), 0, ',', '.')); ?></h2>
                        <h5 class="text-danger mb-0">Poin Dikeluarkan</h5>
                    </div>
                    
                    <!-- Parse barang dari catatan -->
                    <?php
                        $catatan = $transaksi->catatan;
                        $barangInfo = str_replace('Penukaran: ', '', $catatan);
                    ?>
                    
                    <div class="alert alert-danger bg-opacity-10 border-danger">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-box text-danger"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="alert-heading mb-1">Barang yang Ditukar</h6>
                                <p class="mb-0"><?php echo e($barangInfo); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Timeline -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-light">
                    <h6 class="mb-0">
                        <i class="fas fa-history me-2"></i> Timeline Proses
                    </h6>
                </div>
                <div class="card-body">
                    <div class="timeline">
                        <div class="timeline-item completed">
                            <div class="timeline-marker bg-success"></div>
                            <div class="timeline-content">
                                <h6>Pengajuan Penukaran</h6>
                                <p class="text-muted mb-0">
                                    <?php echo e($transaksi->created_at->format('d F Y H:i')); ?>

                                </p>
                                <p class="mb-0">Permintaan penukaran barang diajukan</p>
                            </div>
                        </div>
                        
                        <div class="timeline-item <?php echo e($transaksi->status == 'completed' ? 'completed' : ''); ?>">
                            <div class="timeline-marker bg-<?php echo e($transaksi->status == 'completed' ? 'success' : 'secondary'); ?>"></div>
                            <div class="timeline-content">
                                <h6>Proses Penukaran</h6>
                                <p class="text-muted mb-0">
                                    <?php if($transaksi->status == 'completed'): ?>
                                    <?php echo e($transaksi->updated_at->format('d F Y H:i')); ?>

                                    <?php else: ?>
                                    Sedang diproses
                                    <?php endif; ?>
                                </p>
                                <p class="mb-0">Barang sedang diproses untuk penukaran</p>
                            </div>
                        </div>
                        
                        <div class="timeline-item <?php echo e($transaksi->status == 'completed' ? 'completed' : ''); ?>">
                            <div class="timeline-marker bg-<?php echo e($transaksi->status == 'completed' ? 'success' : 'secondary'); ?>"></div>
                            <div class="timeline-content">
                                <h6>Penukaran Selesai</h6>
                                <p class="text-muted mb-0">
                                    <?php if($transaksi->status == 'completed'): ?>
                                    <?php echo e($transaksi->updated_at->format('d F Y H:i')); ?>

                                    <?php else: ?>
                                    Menunggu
                                    <?php endif; ?>
                                </p>
                                <p class="mb-0">Penukaran barang telah selesai</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Action Buttons -->
    <?php if($transaksi->status == 'completed'): ?>
    <div class="row mt-4">
        <div class="col-12">
            <div class="card border-dashed">
                <div class="card-body text-center">
                    <div class="btn-group" role="group">
                        <a href="<?php echo e(route('warga.barang.index')); ?>" class="btn btn-netra">
                            <i class="fas fa-store me-2"></i> Tukar Barang Lain
                        </a>
                        <button class="btn btn-outline-secondary" onclick="window.print()">
                            <i class="fas fa-print me-2"></i> Cetak Bukti
                        </button>
                        <a href="<?php echo e(route('warga.barang.index', ['tab' => 'riwayat'])); ?>" class="btn btn-outline-info">
                            <i class="fas fa-history me-2"></i> Lihat Semua Riwayat
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('styles'); ?>
<style>
.timeline {
    position: relative;
    padding-left: 30px;
}

.timeline::before {
    content: '';
    position: absolute;
    left: 15px;
    top: 0;
    bottom: 0;
    width: 2px;
    background-color: #dee2e6;
}

.timeline-item {
    position: relative;
    margin-bottom: 30px;
}

.timeline-marker {
    position: absolute;
    left: -30px;
    top: 0;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    border: 3px solid #fff;
    box-shadow: 0 0 0 2px #dee2e6;
    z-index: 1;
}

.timeline-item.completed .timeline-marker {
    box-shadow: 0 0 0 2px var(--bs-success);
}

.timeline-content {
    padding-left: 20px;
}

.bg-opacity-10 {
    background-color: rgba(var(--bs-danger-rgb), 0.1);
}

.card.border-dashed {
    border: 2px dashed #dee2e6;
}

.display-4 {
    font-size: 3.5rem;
}

@media (max-width: 768px) {
    .timeline {
        padding-left: 20px;
    }
    
    .timeline-marker {
        left: -20px;
        width: 12px;
        height: 12px;
    }
    
    .btn-group {
        flex-direction: column;
        gap: 10px;
    }
    
    .btn-group .btn {
        width: 100%;
    }
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\netrash_update\netrash\resources\views/warga/penukaran/show.blade.php ENDPATH**/ ?>