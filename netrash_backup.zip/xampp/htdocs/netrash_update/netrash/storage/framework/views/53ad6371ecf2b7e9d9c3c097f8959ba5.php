<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-4 mb-4">
            <!-- Profile Card -->
            <div class="card mb-4">
                <div class="card-body text-center">
                    <!-- Profile Photo -->
                    <div class="mb-3">
                        <?php if(auth()->user()->profile_photo_path): ?>
                            <img src="<?php echo e(auth()->user()->profile_photo_url); ?>" 
                                 alt="<?php echo e(auth()->user()->name); ?>" 
                                 class="rounded-circle border border-3 border-netra"
                                 style="width: 100px; height: 100px; object-fit: cover;">
                        <?php else: ?>
                            <div class="rounded-circle bg-netra d-inline-flex align-items-center justify-content-center"
                                 style="width: 100px; height: 100px; border: 3px solid #2E8B57;">
                                <span class="text-white fw-bold" style="font-size: 2rem;">
                                    <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <h5 class="mb-1"><?php echo e(auth()->user()->name); ?></h5>
                    <p class="text-muted mb-2"><?php echo e(auth()->user()->email); ?></p>
                    
                    <?php
                        $roleColor = auth()->user()->isAdmin() ? 'danger' : (auth()->user()->isPetugas() ? 'warning' : 'success');
                    ?>
                    <span class="badge bg-<?php echo e($roleColor); ?> mb-3">
                        <?php echo e(ucfirst(auth()->user()->role->name)); ?>

                    </span>
                    
                    <!-- Quick Stats -->
                    <div class="mt-3 small text-muted">
                        <div class="mb-1">
                            <i class="fas fa-calendar-alt me-1"></i>
                            Bergabung <?php echo e(auth()->user()->created_at->format('d M Y')); ?>

                        </div>
                        <?php if(auth()->user()->hasVerifiedEmail()): ?>
                        <div class="text-success">
                            <i class="fas fa-check-circle me-1"></i>
                            Email Terverifikasi
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Navigation -->
                <div class="list-group list-group-flush">
                    <a href="#profile" onclick="showTab('profile')" 
                       class="list-group-item list-group-item-action border-0 active">
                        <i class="fas fa-user me-2"></i>Profile
                    </a>
                    <a href="#password" onclick="showTab('password')" 
                       class="list-group-item list-group-item-action border-0">
                        <i class="fas fa-key me-2"></i>Password
                    </a>
                    <?php if(auth()->user()->isWarga()): ?>
                    <a href="#points" onclick="showTab('points')" 
                       class="list-group-item list-group-item-action border-0">
                        <i class="fas fa-coins me-2"></i>My Points
                    </a>
                    <?php endif; ?>
                    <a href="#preferences" onclick="showTab('preferences')" 
                       class="list-group-item list-group-item-action border-0">
                        <i class="fas fa-cog me-2"></i>Settings
                    </a>
                </div>
            </div>
            
            <!-- Points Summary (Warga only) -->
            <?php if(auth()->user()->isWarga()): ?>
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title mb-3">Points</h6>
                    <div class="text-center">
                        <div class="display-5 text-netra fw-bold mb-1">
                            <?php echo e(number_format(auth()->user()->total_points, 0, ',', '.')); ?>

                        </div>
                        <p class="text-muted mb-3">Total Points</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-8">
            <!-- Messages -->
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fas fa-check-circle me-2"></i>
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <!-- Tab Contents -->
            
            <!-- Profile Tab -->
            <div id="profile-tab" class="tab-content">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Profile Information</h5>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>
                            
                            <!-- Photo Upload -->
                            <div class="row mb-4">
                                <div class="col-md-3">
                                    <label class="form-label">Profile Photo</label>
                                    <div class="position-relative">
                                        <?php if(auth()->user()->profile_photo_path): ?>
                                            <img id="profile-preview" 
                                                 src="<?php echo e(auth()->user()->profile_photo_url); ?>" 
                                                 alt="<?php echo e(auth()->user()->name); ?>" 
                                                 class="rounded-circle border border-3 border-netra"
                                                 style="width: 120px; height: 120px; object-fit: cover;">
                                        <?php else: ?>
                                            <div id="profile-initials" 
                                                 class="rounded-circle bg-netra d-flex align-items-center justify-content-center"
                                                 style="width: 120px; height: 120px; border: 3px solid #2E8B57;">
                                                <span class="text-white fw-bold" style="font-size: 2.5rem;">
                                                    <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

                                                </span>
                                            </div>
                                            <img id="profile-preview" src="" alt="Preview" 
                                                 class="rounded-circle border border-3 border-netra d-none"
                                                 style="width: 120px; height: 120px; object-fit: cover;">
                                        <?php endif; ?>
                                        
                                        <label for="photo" class="position-absolute bottom-0 end-0 bg-netra text-white rounded-circle p-2 cursor-pointer"
                                               style="width: 36px; height: 36px; transform: translate(25%, 25%);">
                                            <i class="fas fa-camera"></i>
                                            <input type="file" id="photo" name="photo" class="d-none" accept="image/*" onchange="previewImage(event)">
                                        </label>
                                    </div>
                                    <?php if(auth()->user()->profile_photo_path): ?>
                                    <button type="button" onclick="removePhoto()" class="btn btn-sm btn-outline-danger mt-2">
                                        <i class="fas fa-trash me-1"></i> Remove
                                    </button>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="col-md-9">
                                    <div class="row">
                                        <!-- Name -->
                                        <div class="col-md-6 mb-3">
                                            <label for="name" class="form-label">Full Name</label>
                                            <input type="text" id="name" name="name" 
                                                   class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                   value="<?php echo e(old('name', auth()->user()->name )); ?>"
                                                   required>
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        
                                        <!-- Email -->
                                        <div class="col-md-6 mb-3">
                                            <label for="email" class="form-label">Email</label>
                                            <input type="email" id="email" name="email" 
                                                   class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                   value="<?php echo e(old('email', auth()->user()->email)); ?>"
                                                   required>
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        
                                        <!-- Phone -->
                                        <div class="col-md-6 mb-3">
                                            <label for="phone" class="form-label">Phone</label>
                                            <input type="tel" id="phone" name="phone" 
                                                   class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                   value="<?php echo e(old('phone', auth()->user()->phone)); ?>"
                                                   placeholder="0812 3456 7890">
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        
                                        <!-- Role-specific fields -->
                                        <?php if(auth()->user()->isWarga()): ?>
                                        <div class="col-md-6 mb-3">
                                            <label for="nik" class="form-label">NIK</label>
                                            <input type="text" id="nik" name="nik" 
                                                   class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                   value="<?php echo e(old('nik', auth()->user()->nik)); ?>">
                                            <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Address -->
                                    <div class="mb-3">
                                        <label for="address" class="form-label">Address</label>
                                        <textarea id="address" name="address" rows="2"
                                                  class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('address', auth()->user()->address)); ?></textarea>
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="border-top pt-3">
                                <button type="submit" class="btn btn-netra">
                                    <i class="fas fa-save me-2"></i>Save Changes
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Password Tab -->
            <div id="password-tab" class="tab-content d-none">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Change Password</h5>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('profile.password.update')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>
                            
                            <!-- Current Password -->
                            <div class="mb-3">
                                <label for="current_password" class="form-label">Current Password</label>
                                <div class="input-group">
                                    <input type="password" id="current_password" name="current_password" 
                                           class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           required>
                                    <button type="button" class="btn btn-outline-secondary" onclick="togglePassword('current_password')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            
                            <!-- New Password -->
                            <div class="mb-3">
                                <label for="password" class="form-label">New Password</label>
                                <div class="input-group">
                                    <input type="password" id="password" name="password" 
                                           class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           required>
                                    <button type="button" class="btn btn-outline-secondary" onclick="togglePassword('password')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <small class="text-muted">Minimal 8 karakter</small>
                            </div>
                            
                            <!-- Confirm Password -->
                            <div class="mb-3">
                                <label for="password_confirmation" class="form-label">Confirm Password</label>
                                <div class="input-group">
                                    <input type="password" id="password_confirmation" name="password_confirmation" 
                                           class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           required>
                                    <button type="button" class="btn btn-outline-secondary" onclick="togglePassword('password_confirmation')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            
                            <div class="border-top pt-3">
                                <button type="submit" class="btn btn-netra">
                                    <i class="fas fa-key me-2"></i>Update Password
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Points Tab (Warga only) -->
            <?php if(auth()->user()->isWarga()): ?>
            <div id="points-tab" class="tab-content d-none">
                <?php
                    $user = auth()->user();
                    $recentTransactions = $user->transaksiSebagaiWarga()->with('petugas')->orderBy('created_at', 'desc')->take(5)->get();
                ?>
                
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">My Points</h5>
                    </div>
                    <div class="card-body">
                        <!-- Points Stats -->
                        <div class="row mb-4">
                            <div class="col-md-6 mb-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <div class="text-netra display-5 fw-bold mb-1">
                                            <?php echo e(number_format($user->total_points, 0, ',', '.')); ?>

                                        </div>
                                        <small class="text-muted">Total Points</small>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <div class="text-netra display-5 fw-bold mb-1">
                                            <?php echo e($user->transaksiSebagaiWarga()->count()); ?>

                                        </div>
                                        <small class="text-muted">Total Transactions</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Actions -->
                        <div class="d-flex gap-2 mb-4">
                            <a href="<?php echo e(route('warga.transaksi.index')); ?>" class="btn btn-outline-netra">
                                <i class="fas fa-history me-2"></i>Transaction History
                            </a>
                        </div>
                        
                        <!-- Recent Transactions -->
                        <h6 class="mb-3">Recent Transactions</h6>
                        
                        <?php if($recentTransactions->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Petugas</th>
                                        <th>Points</th>
                                        <th>Weight</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($transaction->created_at->format('d/m')); ?></td>
                                        <td><?php echo e($transaction->petugas->name ?? '-'); ?></td>
                                        <td class="text-success fw-bold">+<?php echo e(number_format($transaction->total_poin)); ?></td>
                                        <td><?php echo e(number_format($transaction->total_berat, 1)); ?> kg</td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-center mt-3">
                            <a href="<?php echo e(route('warga.transaksi.index')); ?>" class="btn btn-sm btn-outline-netra">
                                View All <i class="fas fa-arrow-right ms-1"></i>
                            </a>
                        </div>
                        <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-receipt display-4 text-muted mb-3"></i>
                            <p class="text-muted">No transactions yet</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Preferences Tab -->
            <div id="preferences-tab" class="tab-content d-none">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Settings</h5>
                    </div>
                    <div class="card-body">
                        <?php if(auth()->user()->preferences ?? false): ?>
                            <?php echo $__env->make('profile.partials.preferences', ['preferences' => $preferences ?? []], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php else: ?>
                        <form method="post" action="<?php echo e(route('profile.preferences.update')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>
                            
                            <div class="mb-3">
                                <label class="form-label">Theme</label>
                                <select name="theme" class="form-select">
                                    <option value="light" <?php echo e((old('theme', 'light') == 'light') ? 'selected' : ''); ?>>Light</option>
                                    <option value="dark" <?php echo e((old('theme', 'light') == 'dark') ? 'selected' : ''); ?>>Dark</option>
                                    <option value="auto" <?php echo e((old('theme', 'light') == 'auto') ? 'selected' : ''); ?>>Auto</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Language</label>
                                <select name="language" class="form-select">
                                    <option value="id" <?php echo e((old('language', 'id') == 'id') ? 'selected' : ''); ?>>Bahasa Indonesia</option>
                                    <option value="en" <?php echo e((old('language', 'id') == 'en') ? 'selected' : ''); ?>>English</option>
                                </select>
                            </div>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" name="email_notifications" class="form-check-input" 
                                       id="email_notifications" <?php echo e((old('email_notifications', true) ? 'checked' : '')); ?>>
                                <label class="form-check-label" for="email_notifications">
                                    Email Notifications
                                </label>
                            </div>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" name="push_notifications" class="form-check-input" 
                                       id="push_notifications" <?php echo e((old('push_notifications', true) ? 'checked' : '')); ?>>
                                <label class="form-check-label" for="push_notifications">
                                    Push Notifications
                                </label>
                            </div>
                            
                            <div class="border-top pt-3">
                                <button type="submit" class="btn btn-netra">
                                    <i class="fas fa-save me-2"></i>Save Settings
                                </button>
                            </div>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Tab Navigation
function showTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.add('d-none');
    });
    
    // Remove active class from all nav items
    document.querySelectorAll('.list-group-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Show selected tab
    const selectedTab = document.getElementById(tabName + '-tab');
    if (selectedTab) {
        selectedTab.classList.remove('d-none');
    }
    
    // Add active class to clicked nav item
    const activeNav = document.querySelector(`[href="#${tabName}"]`);
    if (activeNav) {
        activeNav.classList.add('active');
    }
}

// Password toggle visibility
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const icon = input.nextElementSibling.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

// Image preview
function previewImage(event) {
    const input = event.target;
    const preview = document.getElementById('profile-preview');
    const initials = document.getElementById('profile-initials');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.classList.remove('d-none');
            if (initials) initials.classList.add('d-none');
        }
        
        reader.readAsDataURL(input.files[0]);
    }
}

// Remove photo
function removePhoto() {
    if (confirm('Hapus foto profil?')) {
        // Create a hidden input to indicate photo removal
        let input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'remove_photo';
        input.value = '1';
        document.getElementById('profile-form').appendChild(input);
        
        // Hide current photo and show initials
        document.getElementById('profile-preview').classList.add('d-none');
        document.getElementById('profile-initials').classList.remove('d-none');
    }
}

// Initialize first tab
document.addEventListener('DOMContentLoaded', function() {
    showTab('profile');
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\netrash_update\netrash\resources\views/profile/edit.blade.php ENDPATH**/ ?>