

<?php $__env->startSection('title', 'Penukaran Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-netra text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-shopping-cart me-2"></i> Penukaran Barang
                    </h5>
                </div>
                <div class="card-body">
                    <!-- Barang Info -->
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <img src="<?php echo e($barang->gambar_url); ?>" 
                                 alt="<?php echo e($barang->nama_barang); ?>" 
                                 class="img-fluid rounded">
                        </div>
                        <div class="col-md-8">
                            <h4><?php echo e($barang->nama_barang); ?></h4>
                            <p class="text-muted"><?php echo e($barang->deskripsi); ?></p>
                            <div class="d-flex justify-content-between">
                                <div>
                                    <span class="badge bg-secondary"><?php echo e($barang->kategori ?? 'Umum'); ?></span>
                                    <span class="badge bg-netra ms-2"><?php echo e(number_format($barang->harga_poin)); ?> poin</span>
                                </div>
                                <div>
                                    <small class="text-muted">
                                        <i class="fas fa-box me-1"></i> Stok: <?php echo e($barang->stok); ?>

                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Form Penukaran -->
                    <form action="<?php echo e(route('warga.penukaran.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="barang_id" value="<?php echo e($barang->id); ?>">
                        
                        <div class="mb-3">
                            <label class="form-label">Jumlah</label>
                            <input type="number" 
                                   name="jumlah" 
                                   class="form-control" 
                                   value="1" 
                                   min="1" 
                                   max="<?php echo e($barang->stok); ?>"
                                   required>
                            <div class="form-text">Maksimal: <?php echo e($barang->stok); ?> item</div>
                        </div>
                        
                        <!-- Summary -->
                        <div class="alert alert-info">
                            <div class="d-flex justify-content-between mb-2">
                                <span>Poin Anda:</span>
                                <strong><?php echo e(number_format(auth()->user()->total_points)); ?> pts</strong>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Harga per item:</span>
                                <strong><?php echo e(number_format($barang->harga_poin)); ?> pts</strong>
                            </div>
                            <div class="d-flex justify-content-between fw-bold">
                                <span>Total poin yang akan dikurangi:</span>
                                <strong id="totalPoin"><?php echo e(number_format($barang->harga_poin)); ?> pts</strong>
                            </div>
                            <div class="d-flex justify-content-between mt-2">
                                <span>Sisa poin:</span>
                                <strong id="sisaPoin"><?php echo e(number_format(auth()->user()->total_points - $barang->harga_poin)); ?> pts</strong>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-netra">
                                <i class="fas fa-check me-2"></i> Konfirmasi Penukaran
                            </button>
                            <a href="<?php echo e(route('warga.barang.index')); ?>" class="btn btn-outline-secondary">
                                <i class="fas fa-times me-2"></i> Batal
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const jumlahInput = document.querySelector('input[name="jumlah"]');
    const hargaPoin = <?php echo e($barang->harga_poin); ?>;
    const poinUser = <?php echo e(auth()->user()->total_points); ?>;
    
    function updateSummary() {
        const jumlah = parseInt(jumlahInput.value) || 1;
        const totalPoin = hargaPoin * jumlah;
        const sisaPoin = poinUser - totalPoin;
        
        document.getElementById('totalPoin').textContent = 
            totalPoin.toLocaleString() + ' pts';
        document.getElementById('sisaPoin').textContent = 
            sisaPoin.toLocaleString() + ' pts';
        
        // Validasi
        const submitBtn = document.querySelector('button[type="submit"]');
        if (jumlah > <?php echo e($barang->stok); ?> || totalPoin > poinUser) {
            submitBtn.disabled = true;
            submitBtn.classList.remove('btn-netra');
            submitBtn.classList.add('btn-secondary');
        } else {
            submitBtn.disabled = false;
            submitBtn.classList.remove('btn-secondary');
            submitBtn.classList.add('btn-netra');
        }
    }
    
    jumlahInput.addEventListener('input', updateSummary);
    updateSummary(); // Initial call
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\netrash_update\netrash\resources\views/warga/penukaran/create.blade.php ENDPATH**/ ?>