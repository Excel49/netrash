

<?php $__env->startSection('title', 'Buat Transaksi Kategori'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <h4 class="mb-1">Transaksi Sampah <?php echo e(ucfirst($kategori->jenis_sampah ?? 'Kategori')); ?></h4>
                    <p class="text-muted mb-0">Input sampah <?php echo e($kategori->nama_kategori ?? ''); ?></p>
                </div>
                <div>
                    <a href="<?php echo e(route('petugas.dashboard')); ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Kembali
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Warga Info -->
    <?php if($warga): ?>
    <div class="card mb-4">
        <div class="card-body">
            <div class="row">
                <div class="col-md-8">
                    <h5><?php echo e($warga->name); ?></h5>
                    <p class="mb-1"><strong>Email:</strong> <?php echo e($warga->email); ?></p>
                    <p class="mb-1"><strong>Telepon:</strong> <?php echo e($warga->phone ?? '-'); ?></p>
                    <p class="mb-1"><strong>Poin:</strong> <?php echo e(number_format($warga->total_points, 0, ',', '.')); ?></p>
                </div>
                <div class="col-md-4 text-end">
                    <?php if($warga->qr_code): ?>
                    <img src="<?php echo e(asset('storage/' . $warga->qr_code)); ?>" alt="QR Code" width="80" class="img-thumbnail">
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="alert alert-warning mb-4">
        <i class="fas fa-exclamation-triangle me-2"></i>
        Warga belum dipilih. Silakan scan QR Code terlebih dahulu.
    </div>
    <?php endif; ?>

    <!-- Kategori Info -->
    <?php if($kategori): ?>
    <div class="card mb-4">
        <div class="card-header">
            <h6 class="mb-0">Informasi Kategori</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <h6>Kategori</h6>
                    <p class="fw-bold"><?php echo e($kategori->nama_kategori); ?></p>
                </div>
                <div class="col-md-4">
                    <h6>Harga per kg</h6>
                    <p class="fw-bold text-success">Rp <?php echo e(number_format($kategori->harga_per_kg, 0, ',', '.')); ?></p>
                </div>
                <div class="col-md-4">
                    <h6>Poin per kg</h6>
                    <p class="fw-bold text-primary"><?php echo e($kategori->poin_per_kg); ?> poin</p>
                </div>
            </div>
            <?php if($kategori->deskripsi): ?>
            <div class="mt-3">
                <h6>Deskripsi:</h6>
                <p class="text-muted"><?php echo e($kategori->deskripsi); ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Form Transaksi -->
    <?php if($warga && $kategori): ?>
    <div class="card">
        <div class="card-header">
            <h6 class="mb-0">Input Transaksi</h6>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('petugas.transaksi.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="warga_id" value="<?php echo e($warga->id); ?>">
                <input type="hidden" name="type" value="kategori">
                <input type="hidden" name="kategori_id" value="<?php echo e($kategori->id); ?>">
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Berat Sampah (kg)</label>
                            <div class="input-group">
                                <input type="number" name="berat" class="form-control" 
                                       step="0.1" min="0.1" placeholder="0.0" required
                                       id="berat-input">
                                <span class="input-group-text">kg</span>
                            </div>
                            <small class="text-muted">Minimal 0.1 kg</small>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Catatan (Opsional)</label>
                            <textarea name="catatan" class="form-control" rows="2" 
                                      placeholder="Contoh: Sampah basah, kemasan plastik, dll"></textarea>
                        </div>
                    </div>
                </div>

                <!-- Perhitungan Otomatis -->
                <div class="card bg-light mb-4">
                    <div class="card-body">
                        <h6 class="mb-3">Perhitungan:</h6>
                        <div class="row">
                            <div class="col-md-4">
                                <p class="mb-1">Berat:</p>
                                <h5 id="berat-display">0 kg</h5>
                            </div>
                            <div class="col-md-4">
                                <p class="mb-1">Total Harga:</p>
                                <h5 id="harga-display">Rp 0</h5>
                            </div>
                            <div class="col-md-4">
                                <p class="mb-1">Total Poin:</p>
                                <h5 id="poin-display">0 poin</h5>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tombol Submit -->
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-netra btn-lg">
                        <i class="fas fa-save me-2"></i>Simpan Transaksi
                    </button>
                    <a href="<?php echo e(route('petugas.transaksi.select-type')); ?>?warga_id=<?php echo e($warga->id); ?>" 
                       class="btn btn-outline-secondary">
                        <i class="fas fa-redo me-2"></i>Pilih Jenis Lain
                    </a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const beratInput = document.getElementById('berat-input');
    const beratDisplay = document.getElementById('berat-display');
    const hargaDisplay = document.getElementById('harga-display');
    const poinDisplay = document.getElementById('poin-display');
    
    const hargaPerKg = <?php echo e($kategori->harga_per_kg ?? 0); ?>;
    const poinPerKg = <?php echo e($kategori->poin_per_kg ?? 0); ?>;
    
    function calculate() {
        const berat = parseFloat(beratInput.value) || 0;
        
        // Update display
        beratDisplay.textContent = berat.toFixed(1) + ' kg';
        
        if (berat > 0) {
            const totalHarga = berat * hargaPerKg;
            const totalPoin = berat * poinPerKg;
            
            hargaDisplay.textContent = 'Rp ' + totalHarga.toLocaleString('id-ID');
            poinDisplay.textContent = totalPoin.toLocaleString('id-ID') + ' poin';
        } else {
            hargaDisplay.textContent = 'Rp 0';
            poinDisplay.textContent = '0 poin';
        }
    }
    
    // Event listener
    beratInput.addEventListener('input', calculate);
    
    // Initial calculation
    calculate();
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\netrash_update\netrash\resources\views/petugas/transaksi/create-kategori.blade.php ENDPATH**/ ?>