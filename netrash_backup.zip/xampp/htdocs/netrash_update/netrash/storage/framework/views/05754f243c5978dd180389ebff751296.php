<?php $__env->startSection('title', 'Detail Penukaran Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center">
            <h2 class="mb-0">Detail Penukaran Barang</h2>
            <a href="<?php echo e(route('warga.transaksi.index')); ?>" class="btn btn-netra-outline">
                <i class="bi bi-arrow-left me-2"></i>Kembali ke Transaksi
            </a>
        </div>
        <p class="text-muted">Kode Transaksi: <?php echo e($transaksi->kode_transaksi); ?></p>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <!-- Status Card -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-muted">Status Penukaran</h6>
                        <?php if($transaksi->status == 'pending'): ?>
                        <div class="alert alert-warning mb-0">
                            <h5 class="alert-heading">
                                <i class="bi bi-clock-history me-2"></i>Menunggu
                            </h5>
                            <p class="mb-0">Penukaran sedang diproses.</p>
                        </div>
                        <?php elseif($transaksi->status == 'completed'): ?>
                        <div class="alert alert-success mb-0">
                            <h5 class="alert-heading">
                                <i class="bi bi-check2-circle me-2"></i>Berhasil
                            </h5>
                            <p class="mb-0">Penukaran berhasil dilakukan.</p>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-danger mb-0">
                            <h5 class="alert-heading">
                                <i class="bi bi-x-circle me-2"></i>Dibatalkan
                            </h5>
                            <p class="mb-0">Penukaran dibatalkan.</p>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 text-end">
                        <h6 class="text-muted">Jumlah Poin</h6>
                        <h2 class="text-netra"><?php echo e(number_format(abs($transaksi->total_poin), 0, ',', '.')); ?> Poin</h2>
                        <?php if($transaksi->jenis_transaksi == 'penukaran'): ?>
                        <h6 class="text-danger">Poin Berkurang</h6>
                        <?php else: ?>
                        <h6 class="text-success">Poin Bertambah</h6>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Detail Card -->
        <div class="card mb-4">
            <div class="card-header">
                <h6 class="mb-0">Detail Penukaran</h6>
            </div>
            <div class="card-body">
                <table class="table table-borderless">
                    <tr>
                        <th width="30%">Tanggal Transaksi</th>
                        <td><?php echo e($transaksi->created_at->format('d F Y H:i')); ?></td>
                    </tr>
                    <tr>
                        <th>Total Berat</th>
                        <td><?php echo e(number_format($transaksi->total_berat, 2, ',', '.')); ?> kg</td>
                    </tr>
                    <tr>
                        <th>Catatan</th>
                        <td><?php echo e($transaksi->catatan ?? 'Penukaran barang'); ?></td>
                    </tr>
                    <?php if($transaksi->petugas): ?>
                    <tr>
                        <th>Petugas</th>
                        <td><?php echo e($transaksi->petugas->name); ?></td>
                    </tr>
                    <?php endif; ?>
                </table>
                
                <!-- Detail Barang jika ada -->
                <?php if($transaksi->detailTransaksi && count($transaksi->detailTransaksi) > 0): ?>
                <div class="mt-4">
                    <h6>Detail Barang:</h6>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Kategori</th>
                                    <th>Berat</th>
                                    <th>Poin</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $transaksi->detailTransaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($detail->kategori->nama_kategori ?? '-'); ?></td>
                                    <td><?php echo e(number_format($detail->berat, 2, ',', '.')); ?> kg</td>
                                    <td><?php echo e(number_format($detail->poin, 0, ',', '.')); ?> poin</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Action Buttons -->
        <div class="card mb-4">
            <div class="card-body text-center">
                <?php if($transaksi->status == 'completed'): ?>
                <a href="<?php echo e(route('warga.transaksi.index')); ?>" class="btn btn-netra-outline">
                    <i class="bi bi-list me-2"></i>Lihat Semua Transaksi
                </a>
                <?php if($transaksi->jenis_transaksi == 'penukaran'): ?>
                <a href="<?php echo e(route('warga.barang.index')); ?>" class="btn btn-netra ms-2">
                    <i class="bi bi-basket me-2"></i>Tukar Barang Lain
                </a>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
.timeline {
    position: relative;
    padding-left: 30px;
}

.timeline::before {
    content: '';
    position: absolute;
    left: 15px;
    top: 0;
    bottom: 0;
    width: 2px;
    background-color: #e9ecef;
}

.timeline-item {
    position: relative;
    margin-bottom: 30px;
}

.timeline-marker {
    position: absolute;
    left: -30px;
    top: 0;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    border: 3px solid #fff;
    box-shadow: 0 0 0 2px #e9ecef;
}

.timeline-item.completed .timeline-marker {
    box-shadow: 0 0 0 2px var(--primary-color);
}

.timeline-content {
    padding-left: 20px;
}

.timeline-item.cancelled .timeline-marker {
    background-color: #dc3545 !important;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\netrash_update\netrash\resources\views/warga/transaksi/show.blade.php ENDPATH**/ ?>