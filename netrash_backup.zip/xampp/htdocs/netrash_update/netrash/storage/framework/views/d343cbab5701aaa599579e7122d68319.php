<?php $__env->startSection('title', 'Notifikasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2 class="mb-0">Notifikasi</h2>
                <div>
                    <button type="button" class="btn btn-outline-danger" id="clearAllBtn">
                        <i class="bi bi-trash me-2"></i>Hapus Semua
                    </button>
                </div>
            </div>
            <p class="text-muted">Daftar semua notifikasi Anda</p>
        </div>
    </div>

    <!-- Notification List -->
    <div class="card">
        <div class="card-body p-0">
            <?php $__empty_1 = true; $__currentLoopData = $notifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="notification-item border-bottom">
                <div class="p-3">
                    <div class="d-flex justify-content-between align-items-start">
                        <div class="flex-grow-1">
                            <div class="d-flex align-items-center mb-1">
                                <span class="badge bg-<?php echo e($notif->color); ?> me-2"><?php echo e(ucfirst($notif->tipe)); ?></span>
                                <small class="text-muted"><?php echo e($notif->created_at->diffForHumans()); ?></small>
                            </div>
                            <h6 class="mb-2"><?php echo e($notif->judul); ?></h6>
                            <p class="mb-0"><?php echo e($notif->pesan); ?></p>
                            
                            <?php if($notif->sender_name !== 'Sistem'): ?>
                            <small class="text-muted">
                                Dari: <?php echo e($notif->sender_name); ?> (<?php echo e($notif->sender_role); ?>)
                            </small>
                            <?php endif; ?>
                        </div>
                        <div class="flex-shrink-0 ms-3">
                            <div class="btn-group btn-group-sm">
                                <button type="button" 
                                        class="btn btn-outline-danger delete-btn" 
                                        data-id="<?php echo e($notif->id); ?>">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center py-5">
                <i class="bi bi-bell-slash display-4 text-muted mb-3"></i>
                <p class="text-muted mb-0">Tidak ada notifikasi</p>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Pagination -->
        <?php if($notifikasi->hasPages()): ?>
        <div class="card-footer">
            <?php echo e($notifikasi->links()); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    // Delete notification
    $('.delete-btn').click(function() {
        const id = $(this).data('id');
        const item = $(this).closest('.notification-item');
        
        if (confirm('Apakah Anda yakin ingin menghapus notifikasi ini?')) {
            $.ajax({
                url: `/notifikasi/${id}`,
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.success) {
                        item.remove();
                        
                        // Check if list is empty
                        if ($('.notification-item').length === 0) {
                            $('.card-body').html(`
                                <div class="text-center py-5">
                                    <i class="bi bi-bell-slash display-4 text-muted mb-3"></i>
                                    <p class="text-muted mb-0">Tidak ada notifikasi</p>
                                </div>
                            `);
                        }
                    }
                },
                error: function(xhr) {
                    alert('Gagal menghapus notifikasi');
                }
            });
        }
    });
    
    // Clear all notifications
    $('#clearAllBtn').click(function() {
        if (confirm('Hapus semua notifikasi? Tindakan ini tidak dapat dibatalkan.')) {
            $.ajax({
                url: '/notifikasi/clear-all',
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.success) {
                        $('.card-body').html(`
                            <div class="text-center py-5">
                                <i class="bi bi-bell-slash display-4 text-muted mb-3"></i>
                                <p class="text-muted mb-0">Tidak ada notifikasi</p>
                            </div>
                        `);
                        
                        // Remove badge from navbar
                        $('#notificationBadge').remove();
                    }
                },
                error: function(xhr) {
                    alert('Gagal menghapus semua notifikasi');
                }
            });
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\netrash_update\netrash\resources\views/notifikasi/index.blade.php ENDPATH**/ ?>