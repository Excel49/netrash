<?php
// C:\xampp\htdocs\netrash_update\netrash\database\seeders\KategoriSampahSeeder.php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\KategoriSampah;

class KategoriSampahSeeder extends Seeder
{
    public function run(): void
    {
        $kategoris = [
            [
                'nama_kategori' => 'Organik',
                'jenis_sampah' => 'organik',
                'poin_per_kg' => 10,
                'deskripsi' => 'Sampah organik seperti sisa makanan, daun, buah-buahan',
                'is_locked' => true,
            ],
            [
                'nama_kategori' => 'Anorganik',
                'jenis_sampah' => 'anorganik',
                'poin_per_kg' => 15,
                'deskripsi' => 'Sampah anorganik seperti plastik, kaca, logam',
                'is_locked' => true,
            ],
            [
                'nama_kategori' => 'B3',
                'jenis_sampah' => 'b3',
                'poin_per_kg' => 25,
                'deskripsi' => 'Sampah Bahan Berbahaya dan Beracun seperti baterai, obat kadaluarsa',
                'is_locked' => true,
            ],
            [
                'nama_kategori' => 'Campuran',
                'jenis_sampah' => 'campuran',
                'poin_per_kg' => 7.5,
                'deskripsi' => 'Sampah campuran berbagai jenis',
                'is_locked' => true,
            ],
        ];
        
        foreach ($kategoris as $kategori) {
            KategoriSampah::firstOrCreate(
                ['nama_kategori' => $kategori['nama_kategori']],
                $kategori
            );
        }
    }
}