<?php
// database/seeders/UserSeeder.php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Role;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // Admin
        User::create([
            'name' => 'Admin NetraTrash',
            'email' => 'admin@netratrash.com',
            'password' => Hash::make('admin123'),
            'role_id' => 1,
            'email_verified_at' => now(),
        ]);

        // Petugas
        User::create([
            'name' => 'Petugas 1',
            'email' => 'petugas1@netratrash.com',
            'password' => Hash::make('petugas123'),
            'role_id' => 2,
            'email_verified_at' => now(),
            'total_points' => 0,
        ]);

        User::create([
            'name' => 'Petugas 2',
            'email' => 'petugas2@netratrash.com',
            'password' => Hash::make('petugas123'),
            'role_id' => 2,
            'email_verified_at' => now(),
            'total_points' => 0,
        ]);

        // Warga
        for ($i = 1; $i <= 10; $i++) {
            User::create([
                'name' => 'Warga ' . $i,
                'email' => 'warga' . $i . '@netratrash.com',
                'password' => Hash::make('warga123'),
                'role_id' => 3,
                'email_verified_at' => now(),
                'total_points' => rand(1000, 10000),
                'alamat' => 'Jl. Contoh No. ' . $i,
                'no_hp' => '0812345678' . $i,
            ]);
        }
        
        $this->command->info('Seeder User berhasil dijalankan!');
    }
}