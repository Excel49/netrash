<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('transaksi', function (Blueprint $table) {
            // Tambah kolom untuk status penukaran khusus
            $table->enum('status_penukaran', ['pending', 'completed', 'cancelled', 'processed'])
                  ->nullable()
                  ->after('status');
            
            // Tambah kolom untuk alasan pembatalan
            $table->text('alasan_batal')->nullable()->after('status_penukaran');
            
            // Tambah kolom untuk admin yang memproses
            $table->foreignId('admin_id')->nullable()->constrained('users')->after('alasan_batal');
            
            // Tambah kolom tanggal diproses
            $table->timestamp('diproses_pada')->nullable()->after('admin_id');
            
            // Indeks untuk query yang lebih cepat
            $table->index(['jenis_transaksi', 'status_penukaran']);
            $table->index('admin_id');
        });
    }

    public function down(): void
    {
        Schema::table('transaksi', function (Blueprint $table) {
            $table->dropIndex(['jenis_transaksi', 'status_penukaran']);
            $table->dropIndex(['admin_id']);
            
            $table->dropColumn([
                'status_penukaran',
                'alasan_batal',
                'admin_id',
                'diproses_pada'
            ]);
        });
    }
};