<?php
// database/migrations/2026_01_15_xxxxxx_add_jenis_transaksi_to_transaksi_table.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('transaksi', function (Blueprint $table) {
            $table->string('jenis_transaksi')->default('multi')->after('status'); // 'kategori', 'item', 'multi'
        });
    }

    public function down(): void
    {
        Schema::table('transaksi', function (Blueprint $table) {
            $table->dropColumn('jenis_transaksi');
        });
    }
};