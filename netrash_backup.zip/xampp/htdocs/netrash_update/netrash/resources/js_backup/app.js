// HAPUS semua kode dan ganti dengan:

// Import file bootstrap.js
import './bootstrap';

// Import sweetalert2
import Swal from 'sweetalert2';
window.Swal = Swal;

// Import chart.js
import Chart from 'chart.js/auto';
window.Chart = Chart;

// Import jQuery jika diperlukan
import $ from 'jquery';
window.$ = $;
window.jQuery = $;