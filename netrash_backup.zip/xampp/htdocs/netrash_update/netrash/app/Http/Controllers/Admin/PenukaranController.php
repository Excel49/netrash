<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Transaksi;
use App\Models\User;
use App\Models\Barang;
use App\Models\Notifikasi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PenukaranController extends Controller
{
    /**
     * Display pending penukaran
     */
    public function index()
    {
        $penukaran = Transaksi::with(['warga', 'barangInfo'])
            ->where('jenis_transaksi', 'penukaran')
            ->orderBy('created_at', 'desc')
            ->paginate(20);
        
        $stats = [
            'pending' => Transaksi::where('jenis_transaksi', 'penukaran')
                        ->where('status_penukaran', 'pending')
                        ->count(),
            'completed' => Transaksi::where('jenis_transaksi', 'penukaran')
                          ->where('status_penukaran', 'completed')
                          ->count(),
            'cancelled' => Transaksi::where('jenis_transaksi', 'penukaran')
                          ->where('status_penukaran', 'cancelled')
                          ->count(),
            'processed' => Transaksi::where('jenis_transaksi', 'penukaran')
                          ->where('status_penukaran', 'processed')
                          ->count(),
        ];
        
        return view('admin.penukaran.index', compact('penukaran', 'stats'));
    }
    
    /**
     * Display pending penukaran
     */
    public function pending()
    {
        $penukaran = Transaksi::with(['warga'])
            ->where('jenis_transaksi', 'penukaran')
            ->where('status_penukaran', 'pending')
            ->orderBy('created_at', 'desc')
            ->paginate(20);
        
        return view('admin.penukaran.pending', compact('penukaran'));
    }
    
    /**
     * Display completed penukaran
     */
    public function completed()
    {
        $penukaran = Transaksi::with(['warga', 'admin'])
            ->where('jenis_transaksi', 'penukaran')
            ->where('status_penukaran', 'completed')
            ->orderBy('created_at', 'desc')
            ->paginate(20);
        
        return view('admin.penukaran.completed', compact('penukaran'));
    }
    
    /**
     * Display cancelled penukaran
     */
    public function cancelled()
    {
        $penukaran = Transaksi::with(['warga', 'admin'])
            ->where('jenis_transaksi', 'penukaran')
            ->where('status_penukaran', 'cancelled')
            ->orderBy('created_at', 'desc')
            ->paginate(20);
        
        return view('admin.penukaran.cancelled', compact('penukaran'));
    }
    
    /**
     * Show detail penukaran
     */
    public function show($id)
    {
        $penukaran = Transaksi::with(['warga', 'admin'])
            ->where('jenis_transaksi', 'penukaran')
            ->findOrFail($id);
        
        // Extract barang info dari catatan
        $barangInfo = $this->extractBarangInfo($penukaran->catatan);
        
        return view('admin.penukaran.show', compact('penukaran', 'barangInfo'));
    }
    
    /**
     * Approve penukaran
     */
    public function approve(Request $request, $id)
    {
        $request->validate([
            'catatan_admin' => 'nullable|string|max:500',
        ]);
        
        DB::beginTransaction();
        
        try {
            $penukaran = Transaksi::where('jenis_transaksi', 'penukaran')
                ->where('status_penukaran', 'pending')
                ->findOrFail($id);
            
            $admin = auth()->user();
            
            // Extract barang info dari catatan
            $barangInfo = $this->extractBarangInfo($penukaran->catatan);
            
            // Cari barang
            $barang = Barang::where('nama_barang', 'like', '%' . $barangInfo['nama'] . '%')->first();
            
            if (!$barang) {
                return back()->with('error', 'Barang tidak ditemukan di database');
            }
            
            // Cek stok
            if ($barang->stok < $barangInfo['jumlah']) {
                return back()->with('error', 'Stok barang tidak mencukupi');
            }
            
            // Kurangi stok barang
            $barang->stok -= $barangInfo['jumlah'];
            $barang->save();
            
            // Kurangi poin user
            $warga = User::find($penukaran->warga_id);
            $totalPoin = abs($penukaran->total_poin);
            
            if ($warga->total_points < $totalPoin) {
                return back()->with('error', 'Poin warga tidak mencukupi');
            }
            
            $warga->total_points -= $totalPoin;
            $warga->save();
            
            // Update transaksi
            $penukaran->update([
                'status' => 'completed',
                'status_penukaran' => 'completed',
                'admin_id' => $admin->id,
                'diproses_pada' => now(),
                'catatan' => $penukaran->catatan . (isset($request->catatan_admin) ? "\nCatatan Admin: " . $request->catatan_admin : ''),
            ]);
            
            // Buat notifikasi untuk warga
            Notifikasi::create([
                'user_id' => $penukaran->warga_id,
                'judul' => 'Penukaran Disetujui',
                'pesan' => "Penukaran {$barangInfo['nama']} x{$barangInfo['jumlah']} telah disetujui admin. Poin berkurang {$totalPoin}.",
                'tipe' => 'success',
                'link' => '/warga/transaksi/' . $penukaran->id,
            ]);
            
            DB::commit();
            
            return redirect()->route('admin.penukaran.index')
                ->with('success', 'Penukaran berhasil disetujui!');
                
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }
    
    /**
     * Reject penukaran
     */
    public function reject(Request $request, $id)
    {
        $request->validate([
            'alasan_batal' => 'required|string|max:500',
        ]);
        
        DB::beginTransaction();
        
        try {
            $penukaran = Transaksi::where('jenis_transaksi', 'penukaran')
                ->where('status_penukaran', 'pending')
                ->findOrFail($id);
            
            $admin = auth()->user();
            
            // Update transaksi
            $penukaran->update([
                'status' => 'cancelled',
                'status_penukaran' => 'cancelled',
                'alasan_batal' => $request->alasan_batal,
                'admin_id' => $admin->id,
                'diproses_pada' => now(),
            ]);
            
            // Extract barang info
            $barangInfo = $this->extractBarangInfo($penukaran->catatan);
            
            // Buat notifikasi untuk warga
            Notifikasi::create([
                'user_id' => $penukaran->warga_id,
                'judul' => 'Penukaran Ditolak',
                'pesan' => "Penukaran {$barangInfo['nama']} x{$barangInfo['jumlah']} ditolak. Alasan: {$request->alasan_batal}",
                'tipe' => 'error',
                'link' => '/warga/transaksi/' . $penukaran->id,
            ]);
            
            DB::commit();
            
            return redirect()->route('admin.penukaran.index')
                ->with('success', 'Penukaran berhasil ditolak!');
                
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }
    
    /**
     * Mark as processed (sedang diproses)
     */
    public function process($id)
    {
        DB::beginTransaction();
        
        try {
            $penukaran = Transaksi::where('jenis_transaksi', 'penukaran')
                ->where('status_penukaran', 'pending')
                ->findOrFail($id);
            
            $admin = auth()->user();
            
            $penukaran->update([
                'status_penukaran' => 'processed',
                'admin_id' => $admin->id,
            ]);
            
            // Extract barang info
            $barangInfo = $this->extractBarangInfo($penukaran->catatan);
            
            // Buat notifikasi untuk warga
            Notifikasi::create([
                'user_id' => $penukaran->warga_id,
                'judul' => 'Penukaran Diproses',
                'pesan' => "Penukaran {$barangInfo['nama']} x{$barangInfo['jumlah']} sedang diproses oleh admin.",
                'tipe' => 'info',
                'link' => '/warga/transaksi/' . $penukaran->id,
            ]);
            
            DB::commit();
            
            return redirect()->route('admin.penukaran.index')
                ->with('success', 'Penukaran ditandai sebagai sedang diproses!');
                
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }
    
    /**
     * Helper: Extract barang info dari catatan
     */
    private function extractBarangInfo($catatan)
    {
        // Format: "Penukaran: Nama Barang xJumlah"
        $info = [
            'nama' => 'Barang',
            'jumlah' => 1,
        ];
        
        if (preg_match('/Penukaran:\s*(.+?)\s*x(\d+)/', $catatan, $matches)) {
            $info['nama'] = trim($matches[1]);
            $info['jumlah'] = intval($matches[2]);
        }
        
        return $info;
    }
}