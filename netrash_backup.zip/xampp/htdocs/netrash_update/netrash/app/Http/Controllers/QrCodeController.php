<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class QrCodeController extends Controller
{
    // API Process Scan - HANYA SATU METHOD INI
    public function apiProcessScan(Request $request)
    {
        \Log::info('API Scan Request:', $request->all());
        
        try {
            // Panggil method processScan yang sudah ada
            return $this->processScan($request);
        } catch (\Exception $e) {
            \Log::error('API Scan Error: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'error' => 'Terjadi kesalahan sistem'
            ], 500);
        }
    }
    
    // Tampilkan scanner untuk petugas
    public function scan()
    {
        $user = Auth::user();
        
        if ($user->role_id !== 2) {
            abort(403, 'Hanya petugas yang dapat mengakses halaman ini');
        }
        
        return view('petugas.scan');
    }
    
    // Process scan dari QR Code
    public function processScan(Request $request)
    {
        $user = Auth::user();
        
        if ($user->role_id !== 2) {
            return response()->json([
                'success' => false,
                'error' => 'Unauthorized'
            ], 403);
        }
        
        $qrData = $request->input('qr_data');
        $userId = $request->input('user_id');
        
        try {
            // Jika ada QR data, parse JSON
            if ($qrData) {
                // Cek jika QR data adalah JSON string
                if (is_string($qrData)) {
                    $data = json_decode($qrData, true);
                    if ($data) {
                        $userId = $data['user_id'] ?? $userId;
                    }
                }
            }
            
            // Validasi userId
            if (!$userId) {
                return response()->json([
                    'success' => false,
                    'error' => 'User ID tidak ditemukan dalam QR code'
                ], 400);
            }
            
            // Cari user dengan role warga
            $warga = User::where('id', $userId)
                ->where('role_id', 3) // Pastikan hanya warga
                ->first();
            
            if (!$warga) {
                return response()->json([
                    'success' => false,
                    'error' => 'Warga tidak ditemukan'
                ], 404);
            }
            
            // Data warga ditemukan
            return response()->json([
                'success' => true,
                'user' => [
                    'id' => $warga->id,
                    'name' => $warga->name,
                    'email' => $warga->email,
                    'phone' => $warga->phone,
                    'address' => $warga->address,
                    'total_points' => $warga->total_points ?? 0,
                    'profile_photo_url' => $warga->profile_photo_url ?? null,
                    'qr_code' => $warga->qr_code ?? null
                ]
            ]);
            
        } catch (\Exception $e) {
            \Log::error('QR Scan Error: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'error' => 'Terjadi kesalahan: ' . $e->getMessage()
            ], 500);
        }
    }
    
    // Tampilkan QR Code untuk warga
    public function show()
    {
        $user = Auth::user();
        
        if ($user->role_id !== 3) {
            abort(403, 'Hanya warga yang dapat mengakses halaman ini');
        }
        
        // Generate QR Code jika belum ada
        if (!$user->qr_code) {
            $this->generateQrCode($user);
        }
        
        return view('warga.qrcode', compact('user'));
    }
    
    // Download QR Code
    public function download()
    {
        $user = Auth::user();
        
        if (!$user->qr_code) {
            return back()->with('error', 'QR Code belum tersedia');
        }
        
        $path = storage_path('app/public/' . $user->qr_code);
        
        if (!file_exists($path)) {
            $this->generateQrCode($user);
        }
        
        return response()->download($path, 'qrcode-' . $user->name . '.png');
    }
    
    // Generate QR Code
    private function generateQrCode($user)
    {
        $qrData = json_encode([
            'user_id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'timestamp' => now()->timestamp
        ]);
        
        // Generate QR Code
        $qrCode = QrCode::format('svg')
            ->size(300)
            ->margin(2)
            ->generate($qrData);
        
        // Simpan ke storage
        $fileName = 'qrcodes/user-' . $user->id . '-' . time() . '.png';
        Storage::disk('public')->put($fileName, $qrCode);
        
        // Update user
        $user->qr_code = $fileName;
        $user->save();
        
        return $fileName;
    }
    
    // Search by Email (optional - bisa dihapus jika tidak digunakan)
    public function searchByEmail(Request $request)
    {
        $user = Auth::user();
        
        if ($user->role_id !== 2) {
            return response()->json([
                'success' => false,
                'error' => 'Unauthorized'
            ], 403);
        }
        
        $request->validate([
            'email' => 'required|email'
        ]);
        
        try {
            // AMBIL LANGSUNG DARI DATABASE
            $warga = User::where('email', $request->email)
                ->where('role_id', 3) // Pastikan hanya warga
                ->first();
            
            if (!$warga) {
                return response()->json([
                    'success' => false,
                    'error' => 'Warga tidak ditemukan'
                ], 404);
            }
            
            // Data warga ditemukan dari database
            return response()->json([
                'success' => true,
                'user' => [
                    'id' => $warga->id,
                    'name' => $warga->name,
                    'email' => $warga->email,
                    'phone' => $warga->phone,
                    'address' => $warga->address,
                    'total_points' => $warga->total_points ?? 0,
                    'profile_photo_url' => $warga->profile_photo_url ?? null,
                    'qr_code' => $warga->qr_code ?? null,
                    'created_at' => $warga->created_at->format('d-m-Y'),
                    'total_transactions' => $warga->transaksiSebagaiWarga()->count()
                ]
            ]);
            
        } catch (\Exception $e) {
            \Log::error('Search Email Error: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'error' => 'Terjadi kesalahan: ' . $e->getMessage()
            ], 500);
        }
    }
}